import React, { useState, useEffect, useCallback } from 'react';
import { DragonProvider, useDragon } from './DragonContext';
import { NewTabPage } from './components/NewTabPage';
import { BrowserViewport } from './components/BrowserViewport';
import { FireProgressBar } from './components/FireProgressBar';
import { Settings } from './pages/Settings';
import { Downloads } from './pages/Downloads';
import { History } from './pages/History';
import { Bookmarks } from './pages/Bookmarks';
import { Library } from './pages/Library';
import { ShieldPage } from './pages/ShieldPage';
import { TabSwitcher } from './components/TabSwitcher';
import { QuickNotesPopup } from './components/QuickNotesPopup';
import { NotesLibrary } from './pages/NotesLibrary';
import { FindInPage } from './components/FindInPage';
import { MediaPlayer } from './components/MediaPlayer';
import { ImageViewer } from './components/ImageViewer';
import { BrowserViewMode, Tab } from './types';
import { Home, Shield, Download, Settings as SettingsIcon, ChevronLeft, RotateCcw, Monitor, Mic, Plus, Sparkles, Copy, CheckCircle, X, Pencil, Search, Library as LibraryIcon, SquareStack, Bookmark } from 'lucide-react';
import { useTabs } from './hooks/useTabs';
import { useDragonEngine } from './services/BrowserEngine';
import { normalizeUrl, getDisplayTitle, cleanUrlForDisplay } from './utils/urlUtils';
import { AddressBar } from './components/AddressBar';
import { useVoiceSearch } from './hooks/useVoiceSearch';
import { useDragonAI } from './hooks/useDragonAI';
import { useGestures } from './hooks/useGestures';
import { motion } from 'framer-motion';
import { SplashScreen } from './components/SplashScreen';
import { App as CapacitorApp } from '@capacitor/app';
import { AppLockScreen } from './components/AppLockScreen';
import { SiteSettingsPopup } from './components/SiteSettingsPopup';
import { ShareIntentDialog } from './components/ShareIntentDialog';

const AppContent = () => {
  const { 
    settings, viewMode, setViewMode, updateSettings, addHistory, 
    bookmarks, toggleBookmark, activeMedia, closeMedia,
    isAppLocked, addDownload
  } = useDragon();
  
  const engine = useDragonEngine();
  const { 
    tabs, tabGroups, activeTab, goBack, navigateTab, setTabLoading, 
    createTab, createTabGroup, deleteTabGroup, updateTabGroup, moveTabToGroup,
    reloadTab, closeTab, setActiveTabId, setTabs, duplicateTab,
    clearCurrentSession, closeIncognitoTabs, handleInternalNavigate
  } = useTabs(settings.stealthFlight, settings.searchEngine);
  
  const [urlInputValue, setUrlInputValue] = useState('');
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [isNotesPopupOpen, setIsNotesPopupOpen] = useState(false);
  const [showBookmarkToast, setShowBookmarkToast] = useState(false);
  const [isSiteSettingsOpen, setIsSiteSettingsOpen] = useState(false);
  
  // Share Intent State
  const [shareIntentUrl, setShareIntentUrl] = useState<string | null>(null);
  
  // Find in Page state
  const [isFindActive, setIsFindActive] = useState(false);
  const [findQuery, setFindQuery] = useState('');

  // AI Hooks
  const { fetchSuggestions } = useDragonAI();

  /**
   * Network state check only.
   * Permissions are now requested strictly on-demand by sites or user action.
   */
  const requestPermissionsIfNeeded = useCallback(async () => {
    // Proactive permission requests removed to satisfy "ask only when site requests" policy.
    // This function now primarily serves as a hook for native bridge diagnostics or network checks.
    console.log("Dragon Browser: Lifecycle check triggered (Permissions deferred to usage)");
    console.log("AndroidManifest Compliance: Launch requests disabled. Waiting for site/user triggers.");
    
    // Diagnostic: Check Permissions state without requesting them (Passive check)
    // This confirms readiness for Voice Input/Maps without forcing the prompt.
    if (navigator.permissions && navigator.permissions.query) {
      try {
        const micStatus = await navigator.permissions.query({ name: 'microphone' as PermissionName });
        console.log("Microphone Permission State:", micStatus.state);
      } catch (e) {}

      try {
        const geoStatus = await navigator.permissions.query({ name: 'geolocation' as PermissionName });
        console.log("Location Permission State:", geoStatus.state);
      } catch (e) {}
      
      // Android 13+ Media Permission Check (Passive)
      // Verifies logic for READ_MEDIA_IMAGES, READ_MEDIA_VIDEO, READ_MEDIA_AUDIO
      console.log("Media Access Logic: Granular (Android 13+)");
    }

    console.log("Network Status:", navigator.onLine ? "Online" : "Offline");
  }, []);

  // Robust Permission Request on Mount & Resume & Expose to Window
  useEffect(() => {
    // Expose for Native Bridge calling: window.requestPermissionsIfNeeded()
    (window as any).requestPermissionsIfNeeded = requestPermissionsIfNeeded;

    // Initial call on mount
    setTimeout(requestPermissionsIfNeeded, 1000);

    // Call on Resume (App coming to foreground)
    const listener = CapacitorApp.addListener('appStateChange', ({ isActive }) => {
      if (isActive) {
        requestPermissionsIfNeeded();
      }
    });

    return () => {
      listener.then(l => l.remove());
      delete (window as any).requestPermissionsIfNeeded;
    };
  }, [requestPermissionsIfNeeded]);

  // Apply Theme Logic (Sync with System & Meta Tag)
  useEffect(() => {
    const root = window.document.documentElement;
    const metaThemeColor = document.querySelector('meta[name="theme-color"]');

    const applyTheme = () => {
       const isSystemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
       const isDark = settings.themeMode === 'dark' || (settings.themeMode === 'system' && isSystemDark);
       
       if (isDark) {
         root.classList.add('dark');
         metaThemeColor?.setAttribute('content', '#000000');
       } else {
         root.classList.remove('dark');
         metaThemeColor?.setAttribute('content', '#f8fafc'); // Match bg-slate-50
       }
    };
    
    applyTheme();
    
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = () => {
        if (settings.themeMode === 'system') applyTheme();
    };
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [settings.themeMode]);

  // Hardware Back Button Handling
  useEffect(() => {
    let backListener: any;
    const setupBackListener = async () => {
      // Clean up previous listener to ensure we don't have duplicates
      await CapacitorApp.removeAllListeners();

      backListener = await CapacitorApp.addListener('backButton', () => {
        // 1. Security First: If app locked, back exits the app
        if (isAppLocked) {
          CapacitorApp.exitApp();
          return;
        }

        // 2. Close Media Player / Overlays
        if (activeMedia) {
          closeMedia();
        } else if (isNotesPopupOpen) {
          setIsNotesPopupOpen(false);
        } else if (isSiteSettingsOpen) {
          setIsSiteSettingsOpen(false);
        } else if (isFindActive) {
          setIsFindActive(false);
        } else if (shareIntentUrl) {
          setShareIntentUrl(null);
        } 
        // 3. Navigation Logic
        else if (viewMode !== BrowserViewMode.BROWSER) {
          setViewMode(BrowserViewMode.BROWSER);
        } else if (activeTab.currentIndex > 0) {
          goBack();
        } else {
          // At root of browser history -> Exit App
          CapacitorApp.exitApp();
        }
      });
    };
    
    setupBackListener();
    
    return () => {
      // Cleanup is handled by removeAllListeners at start of next effect or unmount
      if (backListener) backListener.remove();
    };
  }, [
    isAppLocked, activeMedia, isNotesPopupOpen, isSiteSettingsOpen, isFindActive, shareIntentUrl,
    viewMode, activeTab.currentIndex, goBack, closeMedia, setViewMode
  ]);

  const handleReload = useCallback(() => {
    reloadTab();
    setRefreshTrigger(prev => prev + 1);
  }, [reloadTab]);

  const { isListening, interimTranscript, startListening } = useVoiceSearch((transcript) => {
    setUrlInputValue(transcript);
    handleNavigate(transcript);
  });

  // Swipe Gestures for Tab Switching
  const handleSwipeLeft = useCallback(() => {
    // Swipe Left -> Next Tab
    if (viewMode === BrowserViewMode.BROWSER) {
      const currentIndex = tabs.findIndex(t => t.id === activeTab.id);
      if (currentIndex < tabs.length - 1) {
        setActiveTabId(tabs[currentIndex + 1].id);
      }
    }
  }, [viewMode, tabs, activeTab.id, setActiveTabId]);

  const handleSwipeRight = useCallback(() => {
    // Swipe Right -> Previous Tab
    if (viewMode === BrowserViewMode.BROWSER) {
      const currentIndex = tabs.findIndex(t => t.id === activeTab.id);
      if (currentIndex > 0) {
        setActiveTabId(tabs[currentIndex - 1].id);
      }
    }
  }, [viewMode, tabs, activeTab.id, setActiveTabId]);

  const gestureHandlers = useGestures({
    onSwipeLeft: handleSwipeLeft,
    onSwipeRight: handleSwipeRight,
    threshold: 80
  });

  useEffect(() => {
    if (isListening && interimTranscript) {
      setUrlInputValue(interimTranscript);
    }
  }, [isListening, interimTranscript]);

  useEffect(() => {
    if (!isListening) {
      if (activeTab.url === 'dragon://home') {
        setUrlInputValue('');
      } else {
        setUrlInputValue(cleanUrlForDisplay(activeTab.url));
      }
    }
  }, [activeTab.url, isListening]);

  const handleNavigate = useCallback((input: string) => {
    const normalized = input.startsWith('http') || input.startsWith('dragon://') 
      ? input 
      : normalizeUrl(input, settings.searchEngine);
    
    if (normalized !== 'dragon://home') {
      addHistory({ 
        url: normalized, 
        title: getDisplayTitle(normalized) 
      });
    }

    navigateTab(normalized);
    setViewMode(BrowserViewMode.BROWSER);
  }, [navigateTab, settings.searchEngine, setViewMode, addHistory]);

  // Deep Link Listener for Capacitor
  useEffect(() => {
    const setupDeepLinks = async () => {
      await CapacitorApp.addListener('appUrlOpen', (data) => {
        if (data.url) {
          // Check for explicit "Share" scheme from native wrapper (e.g., dragon://share?text=URL)
          if (data.url.startsWith('dragon://share')) {
             try {
                const params = new URL(data.url).searchParams;
                const text = params.get('text') || params.get('url') || '';
                // Extract URL from text if present
                const urlMatch = text.match(/(https?:\/\/[^\s]+)/g);
                const sharedUrl = urlMatch ? urlMatch[0] : text;
                
                if (sharedUrl) {
                  setShareIntentUrl(sharedUrl);
                  return;
                }
             } catch (e) {
               console.error("Failed to parse share intent", e);
             }
          }

          // Check if generic URL is a file
          const ext = data.url.split('.').pop()?.toLowerCase();
          const isFile = ['mp4','webm','mkv','avi','mp3','wav','pdf','zip','apk','rar'].includes(ext || '');
          
          if (isFile) {
             setShareIntentUrl(data.url);
          } else {
             handleNavigate(data.url);
          }
        }
      });

      const launchUrl = await CapacitorApp.getLaunchUrl();
      if (launchUrl?.url) {
        // Simple handling for cold start launch
        if (launchUrl.url.includes('dragon://share')) {
           // Let the listener handle it or re-parse here
           const params = new URL(launchUrl.url).searchParams;
           const sharedUrl = params.get('text') || params.get('url');
           if (sharedUrl) setShareIntentUrl(sharedUrl);
        } else {
           handleNavigate(launchUrl.url);
        }
      }
    };
    setupDeepLinks();
  }, [handleNavigate]);

  const handleShareIntentAction = (action: 'open' | 'download') => {
    if (!shareIntentUrl) return;
    
    if (action === 'download') {
      // Extract filename
      let filename = 'shared_file';
      try {
        const urlPath = new URL(shareIntentUrl).pathname;
        const extracted = urlPath.substring(urlPath.lastIndexOf('/') + 1);
        if (extracted && extracted.length < 50) filename = extracted;
        // Ensure extension
        const ext = shareIntentUrl.split('.').pop();
        if (ext && !filename.endsWith(ext) && ext.length < 5) filename += `.${ext}`;
      } catch (e) {}
      
      addDownload(shareIntentUrl, filename);
      // Optional: Show downloads page
      setViewMode(BrowserViewMode.DOWNLOADS);
    } else {
      handleNavigate(shareIntentUrl);
    }
    setShareIntentUrl(null);
  };

  const handleOpenInNewTab = useCallback((url: string) => {
    const normalized = normalizeUrl(url, settings.searchEngine);
    const newId = Math.random().toString(36).substring(2, 15);
    const newTab: Tab = {
      id: newId,
      url: normalized,
      title: getDisplayTitle(normalized),
      lastAccessed: Date.now(),
      isLoading: true,
      isPrivate: activeTab.isPrivate,
      history: [normalized],
      currentIndex: 0,
      groupId: activeTab.groupId, // Inherit group from current tab
      renderId: 0
    };
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newId);
    setViewMode(BrowserViewMode.BROWSER);
  }, [activeTab.isPrivate, activeTab.groupId, settings.searchEngine, setActiveTabId, setTabs, setViewMode]);

  const handleUrlSubmit = () => {
    if (urlInputValue.trim()) {
      handleNavigate(urlInputValue);
    }
  };

  const handleHomeClick = () => {
    if (activeTab.url === 'dragon://home') {
      setViewMode(BrowserViewMode.BROWSER);
    } else {
      createTab(activeTab.isPrivate, activeTab.groupId);
      setViewMode(BrowserViewMode.BROWSER);
    }
  };

  const handleBookmark = () => {
    toggleBookmark(activeTab.url, activeTab.title);
    setShowBookmarkToast(true);
    setTimeout(() => setShowBookmarkToast(false), 2000);
  };

  const isBookmarked = bookmarks.some(b => b.url === activeTab.url);
  const isHomePage = activeTab.url === 'dragon://home';

  // APP LOCK OVERLAY
  if (isAppLocked) {
    return <AppLockScreen />;
  }

  return (
    <div className="flex flex-col h-screen w-full bg-slate-50 dark:bg-black text-slate-900 dark:text-white overflow-hidden font-sans relative transition-colors duration-300">
      
      {viewMode === BrowserViewMode.BROWSER && (
        <header className="h-[60px] bg-white dark:bg-black border-b border-slate-200 dark:border-white/5 flex items-center px-1 z-50 shrink-0 transition-colors duration-300">
          <div className="flex items-center shrink-0">
            <button 
              onClick={goBack} 
              className="p-1 text-slate-900 dark:text-white active:scale-90 transition-transform disabled:opacity-20 hover:bg-slate-100 dark:hover:bg-white/10 rounded-full"
              disabled={activeTab.currentIndex <= 0}
              title="Back"
            >
              <ChevronLeft size={20} strokeWidth={2.5} />
            </button>
            
            <button 
              onClick={handleHomeClick}
              className="p-1 text-slate-500 hover:text-orange-500 active:scale-90 transition-transform hover:bg-slate-100 dark:hover:bg-white/10 rounded-full"
              title="Home"
            >
              <Home size={20} strokeWidth={2} />
            </button>
          </div>

          <div className="flex-1 min-w-0 mx-1">
            <AddressBar 
              activeTab={activeTab}
              urlInputValue={urlInputValue}
              onUrlChange={setUrlInputValue}
              onUrlSubmit={handleUrlSubmit}
              onReload={handleReload}
              accentColor="#f97316"
              onSiteSettingsClick={() => setIsSiteSettingsOpen(true)}
            />
          </div>

          <div className="flex items-center shrink-0">
            {/* Voice Search */}
            {settings.toolbarConfig.showMic && (
              <button 
                onClick={startListening}
                className={`p-1.5 transition-all active:scale-90 rounded-full hover:bg-slate-100 dark:hover:bg-white/10 ${isListening ? 'text-orange-500 bg-orange-500/10' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'}`}
                title="Voice Search"
              >
                <Mic size={20} className={isListening ? 'animate-pulse' : ''} />
              </button>
            )}

            {/* Toggle Bookmark (Add Bookmark) */}
            {settings.toolbarConfig.showBookmark && (
              <button
                onClick={handleBookmark}
                className={`p-1.5 transition-colors hover:bg-slate-100 dark:hover:bg-white/10 rounded-full ${isBookmarked ? 'text-orange-500' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'}`}
                title="Bookmark"
              >
                <Bookmark size={20} fill={isBookmarked ? "currentColor" : "none"} />
              </button>
            )}

            {/* New Tab */}
            {settings.toolbarConfig.showNewTab && (
              <button 
                onClick={() => createTab(activeTab.isPrivate)}
                className="p-1.5 text-slate-500 hover:text-orange-500 active:scale-90 transition-transform hover:bg-slate-100 dark:hover:bg-white/10 rounded-full"
                title="New Tab"
              >
                <Plus size={20} />
              </button>
            )}

            {!isHomePage && settings.toolbarConfig.showFind && (
              <button 
                onClick={() => setIsFindActive(!isFindActive)}
                className={`p-1.5 transition-all active:scale-90 rounded-full hover:bg-slate-100 dark:hover:bg-white/10 ${isFindActive ? 'text-orange-500' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'}`}
                title="Find in Page"
              >
                <Search size={18} />
              </button>
            )}

            {!isHomePage && settings.toolbarConfig.showDesktopMode && (
              <button 
                onClick={() => updateSettings({ isDesktopMode: !settings.isDesktopMode })}
                className={`p-1.5 transition-all active:scale-90 rounded-full hover:bg-slate-100 dark:hover:bg-white/10 ${settings.isDesktopMode ? 'text-orange-500' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'}`}
                title="Desktop Mode"
              >
                <Monitor size={18} />
              </button>
            )}

            {settings.toolbarConfig.showTabs && (
              <button 
                onClick={() => setViewMode(BrowserViewMode.TAB_SWITCHER)}
                className="p-1.5 text-slate-500 hover:text-slate-900 dark:hover:text-white active:scale-90 transition-transform flex items-center justify-center hover:bg-slate-100 dark:hover:bg-white/10 rounded-full relative group"
                title="Tabs"
              >
                <SquareStack size={20} strokeWidth={2} />
                <span className="absolute -top-1 -right-1 flex items-center justify-center min-w-[14px] h-[14px] px-0.5 bg-orange-500 text-white text-[8px] font-black rounded-full border-[1.5px] border-white dark:border-black shadow-sm">
                  {tabs.length}
                </span>
              </button>
            )}
          </div>
        </header>
      )}

      <main 
        className="flex-1 relative overflow-hidden flex flex-col"
        {...gestureHandlers}
      >
        {showBookmarkToast && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-[120] animate-fade-in pointer-events-none">
            <div className="bg-slate-900/90 backdrop-blur-md text-white px-4 py-2.5 rounded-full flex items-center gap-2 shadow-xl border border-white/10">
              <CheckCircle size={14} className="text-orange-500" />
              <span className="text-[10px] font-black uppercase tracking-widest">Page Bookmarked</span>
            </div>
          </div>
        )}

        <div className={`absolute inset-0 z-0 ${viewMode === BrowserViewMode.BROWSER ? 'visible' : 'invisible pointer-events-none'}`}>
          {tabs.map((tab) => (
            <div 
              key={tab.id}
              className={`absolute inset-0 transition-opacity duration-300 ${tab.id === activeTab.id ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}
            >
              {tab.url === 'dragon://home' ? (
                <NewTabPage 
                  onNavigate={handleNavigate} 
                  onOpenInNewTab={handleOpenInNewTab}
                />
              ) : (
                <div className="w-full h-full relative">
                  <FireProgressBar isLoading={tab.isLoading} themeColor="#f97316" />
                  <BrowserViewport 
                    activeTab={tab}
                    onLoadStart={() => setTabLoading(true)}
                    onLoadEnd={() => setTabLoading(false)}
                    onInternalNavigate={handleInternalNavigate}
                    isDragonBreath={settings.dragonBreath}
                    isDesktopMode={settings.isDesktopMode}
                    javaScriptEnabled={settings.javaScriptEnabled}
                    accentColor="#f97316"
                    onReload={handleReload}
                    refreshTrigger={refreshTrigger}
                  />
                </div>
              )}
            </div>
          ))}
        </div>

        {viewMode !== BrowserViewMode.BROWSER && (
          <div className="absolute inset-0 z-10 bg-slate-50 dark:bg-black animate-fade-in">
            {viewMode === BrowserViewMode.TAB_SWITCHER && (
              <TabSwitcher 
                tabs={tabs} 
                tabGroups={tabGroups}
                activeTabId={activeTab.id} 
                onSelectTab={(id) => { setActiveTabId(id); setViewMode(BrowserViewMode.BROWSER); }}
                onCloseTab={closeTab}
                onDuplicateTab={duplicateTab}
                onCreateTab={createTab}
                onCreateGroup={createTabGroup}
                onDeleteGroup={deleteTabGroup}
                onUpdateGroup={updateTabGroup}
                onMoveTabToGroup={moveTabToGroup}
                onClose={() => setViewMode(BrowserViewMode.BROWSER)}
                onCloseIncognito={closeIncognitoTabs}
                onCloseAll={() => {
                  clearCurrentSession();
                  setViewMode(BrowserViewMode.BROWSER);
                }}
              />
            )}
            {viewMode === BrowserViewMode.SETTINGS && <Settings />}
            {viewMode === BrowserViewMode.DOWNLOADS && <Downloads />}
            {/* Inject props to handle return to Library flow */}
            {viewMode === BrowserViewMode.HISTORY && (
              <History 
                onNavigate={handleNavigate} 
                onBack={() => setViewMode(BrowserViewMode.LIBRARY)} 
              />
            )}
            {viewMode === BrowserViewMode.BOOKMARKS && (
              <Bookmarks 
                onNavigate={handleNavigate} 
                onBack={() => setViewMode(BrowserViewMode.LIBRARY)} 
              />
            )}
            {viewMode === BrowserViewMode.NOTES_LIBRARY && (
              <NotesLibrary 
                onBack={() => setViewMode(BrowserViewMode.LIBRARY)} 
              />
            )}
            {viewMode === BrowserViewMode.LIBRARY && (
              <Library />
            )}
            {viewMode === BrowserViewMode.SHIELD && <ShieldPage />}
          </div>
        )}

        {/* Find in Page Overlay */}
        <FindInPage 
          isActive={isFindActive}
          query={findQuery}
          onQueryChange={setFindQuery}
          current={0}
          total={0}
          onNext={() => {}}
          onPrev={() => {}}
          onClose={() => setIsFindActive(false)}
        />

        {/* Site Settings Popup */}
        <SiteSettingsPopup 
          isOpen={isSiteSettingsOpen}
          onClose={() => setIsSiteSettingsOpen(false)}
          url={activeTab.url}
        />

        {/* Share Intent Dialog */}
        {shareIntentUrl && (
          <ShareIntentDialog 
            url={shareIntentUrl}
            onClose={() => setShareIntentUrl(null)}
            onOpen={() => handleShareIntentAction('open')}
            onDownload={() => handleShareIntentAction('download')}
          />
        )}

        {settings.toolbarConfig.showNotes && (
        <button 
          onClick={() => setIsNotesPopupOpen(true)}
          className="fixed bottom-[90px] right-5 w-14 h-14 bg-[#E11D48] rounded-full flex items-center justify-center shadow-xl shadow-red-900/40 active:scale-90 transition-all z-[60] group border border-white/10"
        >
          <Pencil size={24} className="text-black" strokeWidth={2.5} />
        </button>
        )}

        <QuickNotesPopup 
          isOpen={isNotesPopupOpen} 
          onClose={() => setIsNotesPopupOpen(false)} 
        />
        
        {/* Media Players */}
        {activeMedia && (
          activeMedia.type === 'image' ? (
            <ImageViewer media={activeMedia} onClose={closeMedia} />
          ) : (
            <MediaPlayer media={activeMedia} onClose={closeMedia} />
          )
        )}
      </main>

      <nav className="h-[72px] bg-white dark:bg-black border-t border-slate-200 dark:border-white/5 flex items-center justify-around px-2 z-50 relative pb-safe-bottom transition-colors duration-300">
        <button onClick={() => setViewMode(BrowserViewMode.LIBRARY)} className={`flex flex-col items-center gap-1.5 flex-1 transition-colors group ${viewMode === BrowserViewMode.LIBRARY ? 'text-orange-500' : 'text-slate-500 dark:text-slate-500'}`}>
          <LibraryIcon size={20} className="group-active:scale-90 transition-transform" />
          <span className="text-[9px] font-black uppercase tracking-tighter pb-1">Library</span>
        </button>
        
        <button onClick={() => setViewMode(BrowserViewMode.SHIELD)} className={`flex flex-col items-center gap-1.5 flex-1 transition-colors group ${viewMode === BrowserViewMode.SHIELD ? 'text-orange-500' : 'text-slate-500 dark:text-slate-500'}`}>
          <div className="relative group-active:scale-90 transition-transform">
            <Shield size={20} />
            {settings.adBlockEnabled && <div className="absolute top-0 -right-1 w-1.5 h-1.5 bg-orange-500 rounded-full" />}
          </div>
          <span className="text-[9px] font-black uppercase tracking-tighter pb-1">Shield</span>
        </button>

        <div className="flex-1 flex justify-center -mt-8 relative z-10">
          <motion.button 
            onClick={handleHomeClick}
            className="w-14 h-14 bg-black rounded-full p-0.5 border-2 border-orange-600 shadow-[0_10px_30px_rgba(234,88,12,0.4)] active:scale-90 overflow-hidden relative z-50"
            whileTap={{ scale: 0.9 }}
          >
            <img 
              src="https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg" 
              className="w-full h-full object-cover rounded-full" 
              alt="Dragon Home" 
            />
          </motion.button>
        </div>

        <button onClick={() => setViewMode(BrowserViewMode.DOWNLOADS)} className={`flex flex-col items-center gap-1.5 flex-1 transition-colors group ${viewMode === BrowserViewMode.DOWNLOADS ? 'text-orange-500' : 'text-slate-500 dark:text-slate-500'}`}>
          <Download size={20} className="group-active:scale-90 transition-transform" />
          <span className="text-[9px] font-black uppercase tracking-tighter pb-1">Downloads</span>
        </button>
        
        <button onClick={() => setViewMode(BrowserViewMode.SETTINGS)} className={`flex flex-col items-center gap-1.5 flex-1 transition-colors group ${viewMode === BrowserViewMode.SETTINGS ? 'text-orange-500' : 'text-slate-500 dark:text-slate-500'}`}>
          <SettingsIcon size={20} className="group-active:scale-90 transition-transform" />
          <span className="text-[9px] font-black uppercase tracking-tighter pb-1">Settings</span>
        </button>
      </nav>
    </div>
  );
};

const App = () => {
  const [showSplash, setShowSplash] = useState(true);

  return (
    <DragonProvider>
      {showSplash ? (
        <SplashScreen onFinish={() => setShowSplash(false)} />
      ) : (
        <AppContent />
      )}
    </DragonProvider>
  );
};

export default App;