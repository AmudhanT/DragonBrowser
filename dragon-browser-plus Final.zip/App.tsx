
import React, { useState, useEffect, useCallback } from 'react';
import { DragonProvider, useDragon } from './DragonContext';
import { NewTabPage } from './components/NewTabPage';
import { BrowserViewport } from './components/BrowserViewport';
import { FireProgressBar } from './components/FireProgressBar';
import { Settings } from './pages/Settings';
import { Downloads } from './pages/Downloads';
import { History } from './pages/History';
import { Bookmarks } from './pages/Bookmarks';
import { Library } from './pages/Library';
import { ShieldPage } from './pages/ShieldPage';
import { TabSwitcher } from './components/TabSwitcher';
import { QuickNotesPopup } from './components/QuickNotesPopup';
import { NotesLibrary } from './pages/NotesLibrary';
import { FindInPage } from './components/FindInPage';
import { MediaPlayer } from './components/MediaPlayer';
import { ImageViewer } from './components/ImageViewer';
import { BrowserViewMode, Tab } from './types';
import { Home, Shield, Download, Settings as SettingsIcon, Star, ChevronLeft, RotateCcw, Monitor, Mic, Plus, Sparkles, Copy, CheckCircle, X, Pencil, Search, Library as LibraryIcon, SquareStack } from 'lucide-react';
import { useTabs } from './hooks/useTabs';
import { useDragonEngine } from './services/BrowserEngine';
import { normalizeUrl, getDisplayTitle, cleanUrlForDisplay } from './utils/urlUtils';
import { AddressBar } from './components/AddressBar';
import { useVoiceSearch } from './hooks/useVoiceSearch';
import { useDragonAI } from './hooks/useDragonAI';
import { useGestures } from './hooks/useGestures';
import { motion } from 'framer-motion';
import { SplashScreen } from './components/SplashScreen';
import { App as CapacitorApp } from '@capacitor/app';
import { AppLockScreen } from './components/AppLockScreen';
import { SiteSettingsPopup } from './components/SiteSettingsPopup';
import { ShareIntentDialog } from './components/ShareIntentDialog';

const AppContent = () => {
  const { 
    settings, viewMode, setViewMode, updateSettings, addHistory, 
    bookmarks, toggleBookmark, activeMedia, closeMedia,
    isAppLocked, addDownload
  } = useDragon();
  
  const engine = useDragonEngine();
  const { 
    tabs, tabGroups, activeTab, goBack, navigateTab, setTabLoading, 
    createTab, createTabGroup, deleteTabGroup, updateTabGroup, moveTabToGroup,
    reloadTab, closeTab, setActiveTabId, setTabs, duplicateTab,
    clearCurrentSession, closeIncognitoTabs, handleInternalNavigate
  } = useTabs(settings.stealthFlight, settings.searchEngine);
  
  const [urlInputValue, setUrlInputValue] = useState('');
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [isNotesPopupOpen, setIsNotesPopupOpen] = useState(false);
  const [showBookmarkToast, setShowBookmarkToast] = useState(false);
  const [isSiteSettingsOpen, setIsSiteSettingsOpen] = useState(false);
  
  // Share Intent State
  const [shareIntentUrl, setShareIntentUrl] = useState<string | null>(null);
  
  // Find in Page state
  const [isFindActive, setIsFindActive] = useState(false);
  const [findQuery, setFindQuery] = useState('');

  // AI Hooks
  const { fetchSuggestions } = useDragonAI();

  // Robust Permission Request on Mount
  useEffect(() => {
    const requestRuntimePermissions = async () => {
      console.log("Dragon Browser: Requesting Native Permissions...");
      try {
        await navigator.mediaDevices.getUserMedia({ audio: true })
          .then(() => console.log('Mic granted'))
          .catch((err) => console.log('Mic permission ignored/denied', err));
          
        await navigator.mediaDevices.getUserMedia({ video: true })
          .then(() => console.log('Camera granted'))
          .catch((err) => console.log('Camera permission ignored/denied', err));
        
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(
            () => console.log('Location granted'), 
            (err) => console.log('Location denied', err)
          );
        }
      } catch (error) {
        console.warn("Permission auto-request sequence failed:", error);
      }
    };
    
    setTimeout(requestRuntimePermissions, 1000);
  }, []);

  // Apply Theme Logic (Sync with System & Meta Tag)
  useEffect(() => {
    const root = window.document.documentElement;
    const metaThemeColor = document.querySelector('meta[name="theme-color"]');

    const applyTheme = () => {
       const isSystemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
       const isDark = settings.themeMode === 'dark' || (settings.themeMode === 'system' && isSystemDark);
       
       if (isDark) {
         root.classList.add('dark');
         metaThemeColor?.setAttribute('content', '#000000');
       } else {
         root.classList.remove('dark');
         metaThemeColor?.setAttribute('content', '#f8fafc'); // Match bg-slate-50
       }
    };
    
    applyTheme();
    
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = () => {
        if (settings.themeMode === 'system') applyTheme();
    };
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [settings.themeMode]);

  const handleReload = useCallback(() => {
    reloadTab();
    setRefreshTrigger(prev => prev + 1);
  }, [reloadTab]);

  const { isListening, interimTranscript, startListening } = useVoiceSearch((transcript) => {
    setUrlInputValue(transcript);
    handleNavigate(transcript);
  });

  // Swipe Gestures for Tab Switching
  const handleSwipeLeft = useCallback(() => {
    // Swipe Left -> Next Tab
    if (viewMode === BrowserViewMode.BROWSER) {
      const currentIndex = tabs.findIndex(t => t.id === activeTab.id);
      if (currentIndex < tabs.length - 1) {
        setActiveTabId(tabs[currentIndex + 1].id);
      }
    }
  }, [viewMode, tabs, activeTab.id, setActiveTabId]);

  const handleSwipeRight = useCallback(() => {
    // Swipe Right -> Previous Tab
    if (viewMode === BrowserViewMode.BROWSER) {
      const currentIndex = tabs.findIndex(t => t.id === activeTab.id);
      if (currentIndex > 0) {
        setActiveTabId(tabs[currentIndex - 1].id);
      }
    }
  }, [viewMode, tabs, activeTab.id, setActiveTabId]);

  const gestureHandlers = useGestures({
    onSwipeLeft: handleSwipeLeft,
    onSwipeRight: handleSwipeRight,
    threshold: 80
  });

  useEffect(() => {
    if (isListening && interimTranscript) {
      setUrlInputValue(interimTranscript);
    }
  }, [isListening, interimTranscript]);

  useEffect(() => {
    if (!isListening) {
      if (activeTab.url === 'dragon://home') {
        setUrlInputValue('');
      } else {
        setUrlInputValue(cleanUrlForDisplay(activeTab.url));
      }
    }
  }, [activeTab.url, isListening]);

  const handleNavigate = useCallback((input: string) => {
    const normalized = input.startsWith('http') || input.startsWith('dragon://') 
      ? input 
      : normalizeUrl(input, settings.searchEngine);
    
    if (normalized !== 'dragon://home') {
      addHistory({ 
        url: normalized, 
        title: getDisplayTitle(normalized) 
      });
    }

    navigateTab(normalized);
    setViewMode(BrowserViewMode.BROWSER);
  }, [navigateTab, settings.searchEngine, setViewMode, addHistory]);

  // Deep Link Listener for Capacitor
  useEffect(() => {
    const setupDeepLinks = async () => {
      await CapacitorApp.addListener('appUrlOpen', (data) => {
        if (data.url) {
          // Check for explicit "Share" scheme from native wrapper (e.g., dragon://share?text=URL)
          if (data.url.startsWith('dragon://share')) {
             try {
                const params = new URL(data.url).searchParams;
                const text = params.get('text') || params.get('url') || '';
                // Extract URL from text if present
                const urlMatch = text.match(/(https?:\/\/[^\s]+)/g);
                const sharedUrl = urlMatch ? urlMatch[0] : text;
                
                if (sharedUrl) {
                  setShareIntentUrl(sharedUrl);
                  return;
                }
             } catch (e) {
               console.error("Failed to parse share intent", e);
             }
          }

          // Check if generic URL is a file
          const ext = data.url.split('.').pop()?.toLowerCase();
          const isFile = ['mp4','webm','mkv','avi','mp3','wav','pdf','zip','apk','rar'].includes(ext || '');
          
          if (isFile) {
             setShareIntentUrl(data.url);
          } else {
             handleNavigate(data.url);
          }
        }
      });

      const launchUrl = await CapacitorApp.getLaunchUrl();
      if (launchUrl?.url) {
        // Simple handling for cold start launch
        if (launchUrl.url.includes('dragon://share')) {
           // Let the listener handle it or re-parse here
           const params = new URL(launchUrl.url).searchParams;
           const sharedUrl = params.get('text') || params.get('url');
           if (sharedUrl) setShareIntentUrl(sharedUrl);
        } else {
           handleNavigate(launchUrl.url);
        }
      }
    };
    setupDeepLinks();
  }, [handleNavigate]);

  const handleShareIntentAction = (action: 'open' | 'download') => {
    if (!shareIntentUrl) return;
    
    if (action === 'download') {
      // Extract filename
      let filename = 'shared_file';
      try {
        const urlPath = new URL(shareIntentUrl).pathname;
        const extracted = urlPath.substring(urlPath.lastIndexOf('/') + 1);
        if (extracted && extracted.length < 50) filename = extracted;
        // Ensure extension
        const ext = shareIntentUrl.split('.').pop();
        if (ext && !filename.endsWith(ext) && ext.length < 5) filename += `.${ext}`;
      } catch (e) {}
      
      addDownload(shareIntentUrl, filename);
      // Optional: Show downloads page
      setViewMode(BrowserViewMode.DOWNLOADS);
    } else {
      handleNavigate(shareIntentUrl);
    }
    setShareIntentUrl(null);
  };

  const handleOpenInNewTab = useCallback((url: string) => {
    const normalized = normalizeUrl(url, settings.searchEngine);
    const newId = Math.random().toString(36).substring(2, 15);
    const newTab: Tab = {
      id: newId,
      url: normalized,
      title: getDisplayTitle(normalized),
      lastAccessed: Date.now(),
      isLoading: true,
      isPrivate: activeTab.isPrivate,
      history: [normalized],
      currentIndex: 0,
      groupId: activeTab.groupId, // Inherit group from current tab
      renderId: 0
    };
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newId);
    setViewMode(BrowserViewMode.BROWSER);
  }, [activeTab.isPrivate, activeTab.groupId, settings.searchEngine, setActiveTabId, setTabs, setViewMode]);

  const handleUrlSubmit = () => {
    if (urlInputValue.trim()) {
      handleNavigate(urlInputValue);
    }
  };

  const handleHomeClick = () => {
    if (activeTab.url === 'dragon://home') {
      setViewMode(BrowserViewMode.BROWSER);
    } else {
      createTab(activeTab.isPrivate, activeTab.groupId);
      setViewMode(BrowserViewMode.BROWSER);
    }
  };

  const handleBookmark = () => {
    toggleBookmark(activeTab.url, activeTab.title);
    setShowBookmarkToast(true);
    setTimeout(() => setShowBookmarkToast(false), 2000);
  };

  const isBookmarked = bookmarks.some(b => b.url === activeTab.url);
  const isHomePage = activeTab.url === 'dragon://home';

  // APP LOCK OVERLAY
  if (isAppLocked) {
    return <AppLockScreen />;
  }

  return (
    <div className="flex flex-col h-screen w-full bg-slate-50 dark:bg-black text-slate-900 dark:text-white overflow-hidden font-sans relative transition-colors duration-300">
      
      {viewMode === BrowserViewMode.BROWSER && (
        <header className="h-[60px] bg-white dark:bg-black border-b border-slate-200 dark:border-white/5 flex items-center px-1 z-50 shrink-0 transition-colors duration-300">
          <div className="flex items-center shrink-0">
            <button 
              onClick={goBack} 
              className="p-1 text-slate-900 dark:text-white active:scale-90 transition-transform disabled:opacity-20 hover:bg-slate-100 dark:hover:bg-white/10 rounded-full"
              disabled={activeTab.currentIndex <= 0}
              title="Back"
            >
              <ChevronLeft size={20} strokeWidth={2.5} />
            </button>
            
            <button 
              onClick={handleHomeClick}
              className="p-1 text-slate-500 hover:text-orange-500 active:scale-90 transition-transform hover:bg-slate-100 dark:hover:bg-white/10 rounded-full"
              title="Home"
            >
              <Home size={20} strokeWidth={2} />
            </button>
          </div>

          <div className="flex-1 min-w-0 mx-1">
            <AddressBar 
              activeTab={activeTab}
              urlInputValue={urlInputValue}
              onUrlChange={setUrlInputValue}
              onUrlSubmit={handleUrlSubmit}
              onReload={handleReload}
              accentColor="#f97316"
              onSiteSettingsClick={() => setIsSiteSettingsOpen(true)}
            />
          </div>

          <div className="flex items-center shrink-0">
            {/* Voice Search */}
            {settings.toolbarConfig.showMic && (
              <button 
                onClick={startListening}
                className={`p-1.5 transition-all active:scale-90 rounded-full hover:bg-slate-100 dark:hover:bg-white/10 ${isListening ? 'text-orange-500 bg-orange-500/10' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'}`}
                title="Voice Search"
              >
                <Mic size={20} className={isListening ? 'animate-pulse' : ''} />
              </button>
            )}

            {/* Bookmark */}
            {!isHomePage && settings.toolbarConfig.showBookmark && (
              <button
                onClick={handleBookmark}
                className={`p-1.5 transition-colors hover:bg-slate-100 dark:hover:bg-white/10 rounded-full ${isBookmarked ? 'text-orange-500' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'}`}
                title="Bookmark"
              >
                <Star size={20} fill={isBookmarked ? "currentColor" : "none"} />
              </button>
            )}

            {/* New Tab */}
            {settings.toolbarConfig.showNewTab && (
              <button 
                onClick={() => createTab(activeTab.isPrivate)}
                className="p-1.5 text-slate-500 hover:text-orange-500 active:scale-90 transition-transform hover:bg-slate-100 dark:hover:bg-white/10 rounded-full"
                title="New Tab"
              >
                <Plus size={20} />
              </button>
            )}

            {!isHomePage && settings.toolbarConfig.showFind && (
              <button 
                onClick={() => setIsFindActive(!isFindActive)}
                className={`p-1.5 transition-all active:scale-90 rounded-full hover:bg-slate-100 dark:hover:bg-white/10 ${isFindActive ? 'text-orange-500' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'}`}
                title="Find in Page"
              >
                <Search size={18} />
              </button>
            )}

            {!isHomePage && settings.toolbarConfig.showDesktopMode && (
              <button 
                onClick={() => updateSettings({ isDesktopMode: !settings.isDesktopMode })}
                className={`p-1.5 transition-all active:scale-90 rounded-full hover:bg-slate-100 dark:hover:bg-white/10 ${settings.isDesktopMode ? 'text-orange-500' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'}`}
                title="Desktop Mode"
              >
                <Monitor size={18} />
              </button>
            )}

            {settings.toolbarConfig.showTabs && (
              <button 
                onClick={() => setViewMode(BrowserViewMode.TAB_SWITCHER)}
                className="p-1.5 text-slate-500 hover:text-slate-900 dark:hover:text-white active:scale-90 transition-transform flex items-center justify-center hover:bg-slate-100 dark:hover:bg-white/10 rounded-full relative group"
                title="Tabs"
              >
                <SquareStack size={20} strokeWidth={2} />
                <span className="absolute -top-1 -right-1 flex items-center justify-center min-w-[14px] h-[14px] px-0.5 bg-orange-500 text-white text-[8px] font-black rounded-full border-[1.5px] border-white dark:border-black shadow-sm">
                  {tabs.length}
                </span>
              </button>
            )}
          </div>
        </header>
      )}

      <main 
        className="flex-1 relative overflow-hidden flex flex-col"
        {...gestureHandlers}
      >
        {showBookmarkToast && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-[120] animate-fade-in pointer-events-none">
            <div className="bg-slate-900/90 backdrop-blur-md text-white px-4 py-2.5 rounded-full flex items-center gap-2 shadow-xl border border-white/10">
              <CheckCircle size={14} className="text-orange-500" />
              <span className="text-[10px] font-black uppercase tracking-widest">Page Bookmarked</span>
            </div>
          </div>
        )}

        <div className={`absolute inset-0 z-0 ${viewMode === BrowserViewMode.BROWSER ? 'visible' : 'invisible pointer-events-none'}`}>
          {tabs.map((tab) => (
            <div 
              key={tab.id}
              className={`absolute inset-0 transition-opacity duration-300 ${tab.id === activeTab.id ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}
            >
              {tab.url === 'dragon://home' ? (
                <NewTabPage 
                  onNavigate={handleNavigate} 
                  onOpenInNewTab={handleOpenInNewTab}
                />
              ) : (
                <div className="w-full h-full relative">
                  <FireProgressBar isLoading={tab.isLoading} themeColor="#f97316" />
                  <BrowserViewport 
                    activeTab={tab}
                    onLoadStart={() => setTabLoading(true)}
                    onLoadEnd={() => setTabLoading(false)}
                    onInternalNavigate={handleInternalNavigate}
                    isDragonBreath={settings.dragonBreath}
                    isDesktopMode={settings.isDesktopMode}
                    javaScriptEnabled={settings.javaScriptEnabled}
                    accentColor="#f97316"
                    onReload={handleReload}
                    refreshTrigger={refreshTrigger}
                  />
                </div>
              )}
            </div>
          ))}
        </div>

        {viewMode !== BrowserViewMode.BROWSER && (
          <div className="absolute inset-0 z-10 bg-slate-50 dark:bg-black animate-fade-in">
            {viewMode === BrowserViewMode.TAB_SWITCHER && (
              <TabSwitcher 
                tabs={tabs} 
                tabGroups={tabGroups}
                activeTabId={activeTab.id} 
                onSelectTab={(id) => { setActiveTabId(id); setViewMode(BrowserViewMode.BROWSER); }}
                onCloseTab={closeTab}
                onDuplicateTab={duplicateTab}
                onCreateTab={createTab}
                onCreateGroup={createTabGroup}
                onDeleteGroup={deleteTabGroup}
                onUpdateGroup={updateTabGroup}
                onMoveTabToGroup={moveTabToGroup}
                onClose={() => setViewMode(BrowserViewMode.BROWSER)}
                onCloseIncognito={closeIncognitoTabs}
                onCloseAll={() => {
                  clearCurrentSession();
                  setViewMode(BrowserViewMode.BROWSER);
                }}
              />
            )}
            {viewMode === BrowserViewMode.SETTINGS && <Settings />}
            {viewMode === BrowserViewMode.DOWNLOADS && <Downloads />}
            {viewMode === BrowserViewMode.HISTORY && <History />}
            {viewMode === BrowserViewMode.BOOKMARKS && <Bookmarks onNavigate={handleNavigate} />}
            {viewMode === BrowserViewMode.NOTES_LIBRARY && <NotesLibrary />}
            {viewMode === BrowserViewMode.LIBRARY && (
              <Library 
                onNavigate={handleNavigate} 
                onBookmark={handleBookmark}
                isBookmarked={isBookmarked}
              />
            )}
            {viewMode === BrowserViewMode.SHIELD && <ShieldPage />}
          </div>
        )}

        {/* Find in Page Overlay */}
        <FindInPage 
          isActive={isFindActive}
          query={findQuery}
          onQueryChange={setFindQuery}
          current={0}
          total={0}
          onNext={() => {}}
          onPrev={() => {}}
          onClose={() => setIsFindActive(false)}
        />

        {/* Site Settings Popup */}
        <SiteSettingsPopup 
          isOpen={isSiteSettingsOpen}
          onClose={() => setIsSiteSettingsOpen(false)}
          url={activeTab.url}
        />

        {/* Share Intent Dialog */}
        {shareIntentUrl && (
          <ShareIntentDialog 
            url={shareIntentUrl}
            onClose={() => setShareIntentUrl(null)}
            onOpen={() => handleShareIntentAction('open')}
            onDownload={() => handleShareIntentAction('download')}
          />
        )}

        {settings.toolbarConfig.showNotes && (
        <button 
          onClick={() => setIsNotesPopupOpen(true)}
          className="fixed bottom-[90px] right-5 w-14 h-14 bg-[#E11D48] rounded-full flex items-center justify-center shadow-xl shadow-red-900/40 active:scale-90 transition-all z-[60] group border border-white/10"
        >
          <Pencil size={24} className="text-black" strokeWidth={2.5} />
        </button>
        )}

        <QuickNotesPopup 
          isOpen={isNotesPopupOpen} 
          onClose={() => setIsNotesPopupOpen(false)} 
        />
        
        {/* Media Players */}
        {activeMedia && (
          activeMedia.type === 'image' ? (
            <ImageViewer media={activeMedia} onClose={closeMedia} />
          ) : (
            <MediaPlayer media={activeMedia} onClose={closeMedia} />
          )
        )}
      </main>

      <nav className="h-[72px] bg-white dark:bg-black border-t border-slate-200 dark:border-white/5 flex items-center justify-around px-2 z-50 relative pb-safe-bottom transition-colors duration-300">
        <button onClick={() => setViewMode(BrowserViewMode.LIBRARY)} className={`flex flex-col items-center gap-1 flex-1 transition-colors ${viewMode === BrowserViewMode.LIBRARY ? 'text-orange-500' : 'text-slate-500 dark:text-slate-500'}`}>
          <LibraryIcon size={18} />
          <span className="text-[8px] font-black uppercase tracking-tighter">Library</span>
        </button>
        
        <button onClick={() => setViewMode(BrowserViewMode.SHIELD)} className={`flex flex-col items-center gap-1 flex-1 transition-colors ${viewMode === BrowserViewMode.SHIELD ? 'text-orange-500' : 'text-slate-500 dark:text-slate-500'}`}>
          <div className="relative">
            <Shield size={18} />
            {settings.adBlockEnabled && <div className="absolute top-0 -right-1 w-1.5 h-1.5 bg-orange-500 rounded-full" />}
          </div>
          <span className="text-[8px] font-black uppercase tracking-tighter">Shield</span>
        </button>

        <div className="flex-1 flex justify-center -mt-8 relative z-10">
          <motion.button 
            onClick={handleHomeClick}
            className="w-14 h-14 bg-black rounded-full p-0.5 border-2 border-orange-600 shadow-[0_10px_30px_rgba(234,88,12,0.4)] active:scale-90 overflow-hidden relative z-50"
            whileTap={{ scale: 0.9 }}
          >
            <img 
              src="https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg" 
              className="w-full h-full object-cover rounded-full" 
              alt="Dragon Home" 
            />
          </motion.button>
        </div>

        <button onClick={() => setViewMode(BrowserViewMode.DOWNLOADS)} className={`flex flex-col items-center gap-1 flex-1 transition-colors ${viewMode === BrowserViewMode.DOWNLOADS ? 'text-orange-500' : 'text-slate-500 dark:text-slate-500'}`}>
          <Download size={18} />
          <span className="text-[8px] font-black uppercase tracking-tighter">Downloads</span>
        </button>
        
        <button onClick={() => setViewMode(BrowserViewMode.SETTINGS)} className={`flex flex-col items-center gap-1 flex-1 transition-colors ${viewMode === BrowserViewMode.SETTINGS ? 'text-orange-500' : 'text-slate-500 dark:text-slate-500'}`}>
          <SettingsIcon size={18} />
          <span className="text-[8px] font-black uppercase tracking-tighter">Settings</span>
        </button>
      </nav>
    </div>
  );
};

const App = () => {
  const [showSplash, setShowSplash] = useState(true);

  return (
    <>
      {showSplash && <SplashScreen onFinish={() => setShowSplash(false)} />}
      {!showSplash && (
        <DragonProvider>
          <AppContent />
        </DragonProvider>
      )}
    </>
  );
};

export default App;
