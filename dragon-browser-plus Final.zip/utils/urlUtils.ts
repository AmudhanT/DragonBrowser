
import { SearchEngine } from '../types';

/**
 * SOVEREIGN CORE OMNIBOX LOGIC (v2.2 Standardized)
 * - Dragon Engine now utilizes standard web search protocols for stability.
 * - Maintains iframe (igu=1) support for compatibility.
 */

export const SEARCH_ENGINES_CONFIG: Record<string, { name: string, url: string }> = {
  google: { 
    name: "Google Global", 
    // Force igu=1 for iframe compatibility in Dragon WebView
    url: "https://www.google.com/search?igu=1&q=" 
  },
  dragon: { 
    name: "Dragon Search", 
    // Redirect to Google as the reliable search core, ensuring igu=1 for iframing
    url: "https://www.google.com/search?igu=1&q=" 
  },
  bing: { 
    name: "Microsoft Bing", 
    url: "https://www.bing.com/search?q=" 
  }
};

export const enforceSovereignProtocol = (url: string): string => {
  let processed = url;

  // Google Iframe Fix (The "Working Method")
  // Forces igu=1 on all Google domains to allow embedding
  if (processed.includes('google.com') || processed.includes('google.co')) {
    if (!processed.includes('igu=1')) {
       const separator = processed.includes('?') ? '&' : '?';
       const [base, hash] = processed.split('#');
       processed = `${base}${separator}igu=1${hash ? '#' + hash : ''}`;
    }
  }
  
  return processed;
};

export const cleanUrlForDisplay = (url: string): string => {
  if (!url || url === 'dragon://home') return '';
  
  try {
    const urlObj = new URL(url);
    // Hide the technical 'igu' parameter from the user for a cleaner look
    if (urlObj.hostname.includes('google.com')) {
      const query = urlObj.searchParams.get('q');
      if (query) return query;
      urlObj.searchParams.delete('igu');
    }
    return urlObj.toString();
  } catch {
    return url;
  }
};

export const normalizeUrl = (input: string, engine: SearchEngine = 'google'): string => {
  const query = input ? input.trim() : "";
  if (!query) return 'dragon://home';
  if (query.startsWith('dragon://')) return query;

  // 1. Handle exact "google" or "google.com" entry
  const lowerQuery = query.toLowerCase();
  if (lowerQuery === 'google' || lowerQuery === 'google.com' || lowerQuery === 'www.google.com') {
    return "https://www.google.com/?igu=1";
  }

  // 2. Handle Domain detection (e.g. "example.com")
  const domainRegex = /^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(:\d+)?(\/.*)?$/;
  const hasDomain = domainRegex.test(query) || query.startsWith("http");
  
  if (hasDomain && !query.includes(' ')) {
    let finalUrl = query.startsWith("http") ? query : `https://${query}`;
    return enforceSovereignProtocol(finalUrl);
  } 
  
  // 3. Handle Search Query
  const engineConfig = SEARCH_ENGINES_CONFIG[engine] || SEARCH_ENGINES_CONFIG.google;
  const finalUrl = `${engineConfig.url}${encodeURIComponent(query)}`;
  
  // Apply protocol enforcement to ensure iframe compatibility
  return enforceSovereignProtocol(finalUrl);
};

export const getDisplayTitle = (url: string): string => {
  if (!url || url === 'dragon://home') return 'Dragon Search';
  
  try {
    const urlObj = new URL(url);
    if (urlObj.hostname.includes('google.com')) {
      const q = urlObj.searchParams.get('q');
      if (q) return `${q} - Dragon Search`;
    }
    const host = urlObj.hostname.replace('www.', '');
    return host.charAt(0).toUpperCase() + host.slice(1);
  } catch {
    return url;
  }
};
