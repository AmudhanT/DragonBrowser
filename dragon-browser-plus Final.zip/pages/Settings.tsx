
import React, { useRef, useState } from 'react';
import { useDragon } from '../DragonContext';
import DragonHeader from '../components/DragonHeader';
import { 
  Palette, Search, Check, Monitor, 
  ChevronRight, Zap, Fingerprint, Lock, ShieldCheck,
  Download, Upload, Send, Mail, ShieldAlert,
  Clock, Trash2, LayoutGrid, Sun, Moon,
  Info, Mic, Pencil, FolderOpen, Heart, AlertTriangle,
  Globe, Server, Sparkles, Star, Layers, Plus, Image as ImageIcon, Code, BellOff, PictureInPicture,
  ExternalLink, Camera, Shield, FileJson, RefreshCcw,
  Smartphone, SlidersHorizontal, ToggleRight, ToggleLeft, Layout, Bell, HelpCircle, CheckCircle, XCircle, PlayCircle, Square, MapPin, Cookie, Database, Radar, Ghost, WifiOff, FileText, Settings as SettingsIcon, Languages
} from 'lucide-react';
import { SearchEngine, AppSettings, BrowserViewMode, ThemeMode, ToolbarConfig, SettingsPage, CookiePolicy, PermissionState, AutoCloseDuration } from '../types';
import { AppLockScreen } from '../components/AppLockScreen';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';

const WALLPAPER_PRESETS = [
  { id: 'default', name: 'Dragon', url: 'https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg' },
  { id: 'void', name: 'Void', url: '' },
  { id: 'neon_tokyo', name: 'Neon City', url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=1920&auto=format&fit=crop' },
  { id: 'deep_space', name: 'Cosmos', url: 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?q=80&w=1920&auto=format&fit=crop' },
  { id: 'northern_lights', name: 'Aurora', url: 'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?q=80&w=1920&auto=format&fit=crop' },
  { id: 'crimson_flow', name: 'Inferno', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1920&auto=format&fit=crop' },
  { id: 'rainy_glass', name: 'Rain', url: 'https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?q=80&w=1920&auto=format&fit=crop' },
  { id: 'cyber_grid', name: 'Matrix', url: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=1920&auto=format&fit=crop' },
];

export const Settings: React.FC = () => {
  const { settings, updateSettings, setViewMode, purgeAllData, architect, settingsSection, setSettingsSection, settingsSource, setSettingsSource, t, checkAndRequestNotificationPermission, savedPages, deleteSavedPage } = useDragon();
  const [searchQuery, setSearchQuery] = useState('');
  const [showPinSetup, setShowPinSetup] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const importInputRef = useRef<HTMLInputElement>(null);
  
  const handleToggle = (key: keyof AppSettings) => {
    updateSettings({ [key]: !settings[key] });
  };

  const handleNotificationToggle = async () => {
    if (!settings.notificationsEnabled) {
      // Trying to enable
      const granted = await checkAndRequestNotificationPermission();
      if (granted) {
        updateSettings({ notificationsEnabled: true });
      } else {
        // Revert or keep disabled if permission denied
        updateSettings({ notificationsEnabled: false });
        alert("Notification permission denied by system. Please enable it in Android Settings.");
      }
    } else {
      // Disabling
      updateSettings({ notificationsEnabled: false });
    }
  };

  const handlePinSetupComplete = (pin: string) => {
    updateSettings({ security: { ...settings.security, appLockEnabled: true, pin: pin } });
    setShowPinSetup(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        updateSettings({ wallpaper: base64String });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleToolbarToggle = (key: keyof ToolbarConfig) => {
    updateSettings({ 
      toolbarConfig: { ...settings.toolbarConfig, [key]: !settings.toolbarConfig[key] } 
    });
  };

  const handleExportSettings = async () => {
    const exportData = {
      meta: {
        version: '1.0',
        app: 'Dragon Browser',
        date: new Date().toISOString()
      },
      settings: settings // Only export settings, excludes history/downloads etc stored in other keys
    };
    
    const fileName = `dragon_config_${Date.now()}.json`;
    const jsonString = JSON.stringify(exportData, null, 2);

    try {
      // 1. Try Capacitor Filesystem Write
      await Filesystem.writeFile({
        path: `exports/${fileName}`,
        data: jsonString,
        directory: Directory.Documents,
        encoding: Encoding.UTF8,
        recursive: true
      });
      alert(`Settings exported to Documents/exports/${fileName}`);
    } catch (e) {
      // 2. Fallback to Web Download
      const blob = new Blob([jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleImportSettings = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content);
        
        if (parsed.meta?.app === 'Dragon Browser' && parsed.settings) {
          // Validate critical fields if needed, or just merge
          updateSettings(parsed.settings);
          alert('Settings imported successfully.');
        } else {
          alert('Invalid Dragon configuration file.');
        }
      } catch (error) {
        console.error('Import failed', error);
        alert('Failed to parse settings file.');
      }
      if (importInputRef.current) importInputRef.current.value = '';
    };
    reader.readAsText(file);
  };

  const renderToggle = (label: string, value: boolean, onToggle: () => void, icon?: React.ReactNode) => (
    <div className="flex items-center justify-between p-5 bg-white dark:bg-dragon-navy/50 rounded-2xl border border-slate-200 dark:border-white/5 transition-all shadow-sm">
      <div className="flex items-center gap-4">
        <div className="p-2.5 bg-slate-100 dark:bg-white/5 rounded-xl text-slate-500 dark:text-slate-400">
          {icon}
        </div>
        <div className="flex flex-col">
          <span className="text-[13px] font-bold uppercase tracking-tight text-slate-800 dark:text-slate-200">{label}</span>
        </div>
      </div>
      <button
        onClick={onToggle}
        className={`w-12 h-7 rounded-full relative transition-all duration-300 shadow-inner ${value ? 'bg-dragon-ember' : 'bg-slate-300 dark:bg-slate-700'}`}
      >
        <div className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow-lg transition-all duration-300 ${value ? 'translate-x-6' : 'translate-x-1'}`} />
      </button>
    </div>
  );

  const renderAppearanceSettings = () => {
    const isCustomWallpaper = settings.wallpaper.startsWith('data:');
    
    return (
      <div className="space-y-10 animate-fade-in pb-12">
        {/* Theme Mode */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 px-1">
            <Palette size={16} className="text-dragon-ember" />
            <h4 className="text-[10px] font-black uppercase tracking-[0.25em] text-slate-500 dark:text-slate-400">{t('system_mode')}</h4>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {[
              { id: 'light', name: t('light'), icon: <Sun size={20} /> },
              { id: 'dark', name: t('dark'), icon: <Moon size={20} /> },
              { id: 'system', name: t('auto'), icon: <Smartphone size={20} /> },
            ].map(t => (
              <button 
                key={t.id}
                onClick={() => updateSettings({ themeMode: t.id as ThemeMode })}
                className={`flex flex-col items-center justify-center gap-3 p-5 rounded-[1.8rem] border transition-all active:scale-95 ${settings.themeMode === t.id ? 'bg-dragon-ember text-white border-dragon-ember shadow-lg shadow-dragon-ember/20' : 'bg-white dark:bg-[#151515] border-slate-200 dark:border-white/5 text-slate-400 hover:bg-slate-50 dark:hover:bg-white/5'}`}
              >
                {t.icon}
                <span className="text-[10px] font-bold uppercase tracking-widest">{t.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Wallpapers */}
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-2">
              <ImageIcon size={16} className="text-pink-500" />
              <h4 className="text-[10px] font-black uppercase tracking-[0.25em] text-slate-500 dark:text-slate-400">{t('background')}</h4>
            </div>
            <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept="image/*" className="hidden" />
          </div>
          
          <div className="flex gap-3 overflow-x-auto no-scrollbar pb-4 -mx-6 px-6">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="relative shrink-0 w-28 h-40 rounded-[1.5rem] border-2 border-dashed border-slate-300 dark:border-white/10 bg-slate-100 dark:bg-white/5 flex flex-col items-center justify-center gap-2 hover:bg-slate-200 dark:hover:bg-white/10 transition-all group"
            >
              <Upload size={20} className="text-slate-400 group-hover:text-dragon-ember transition-colors" />
              <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{t('upload')}</span>
            </button>

            {isCustomWallpaper && (
              <button
                onClick={() => updateSettings({ wallpaper: settings.wallpaper })}
                className={`relative shrink-0 w-28 h-40 rounded-[1.5rem] overflow-hidden border-2 transition-all ${!WALLPAPER_PRESETS.some(p => p.id === settings.wallpaper) ? 'border-dragon-ember ring-2 ring-dragon-ember/30' : 'border-transparent opacity-70'}`}
              >
                <img src={settings.wallpaper} className="w-full h-full object-cover" alt="Custom" />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                   <span className="text-[9px] font-black text-white uppercase tracking-widest bg-black/50 px-2 py-1 rounded-lg backdrop-blur-sm">{t('custom')}</span>
                </div>
              </button>
            )}

            {WALLPAPER_PRESETS.map((wp) => (
              <button
                key={wp.id}
                onClick={() => updateSettings({ wallpaper: wp.id })}
                className={`relative shrink-0 w-28 h-40 rounded-[1.5rem] overflow-hidden border-2 transition-all shadow-md ${settings.wallpaper === wp.id ? 'border-dragon-ember ring-2 ring-dragon-ember/30 scale-105 z-10' : 'border-transparent opacity-70 hover:opacity-100'}`}
              >
                {wp.url ? (
                  <img src={wp.url} className="w-full h-full object-cover" alt={wp.name} />
                ) : (
                  <div className="w-full h-full bg-slate-900 flex items-center justify-center text-slate-600">
                    <ShieldCheck size={24} />
                  </div>
                )}
                <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/90 to-transparent">
                  <span className="text-[9px] font-bold text-white uppercase tracking-widest block truncate">{wp.name}</span>
                </div>
                {settings.wallpaper === wp.id && (
                  <div className="absolute top-2 right-2 bg-dragon-ember rounded-full p-1 shadow-lg">
                    <Check size={10} className="text-white" strokeWidth={4} />
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Blur Control */}
        <div className="space-y-4 p-5 bg-white dark:bg-[#151515] rounded-[2rem] border border-slate-200 dark:border-white/5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <SlidersHorizontal size={16} className="text-blue-400" />
              <h4 className="text-[10px] font-black uppercase tracking-[0.25em] text-slate-500 dark:text-slate-400">{t('wallpaper_blur')}</h4>
            </div>
            <span className="text-[10px] font-bold text-slate-900 dark:text-white bg-slate-100 dark:bg-white/10 px-2 py-1 rounded-lg">{settings.wallpaperBlur}px</span>
          </div>
          <input
            type="range"
            min="0"
            max="50"
            step="1"
            value={settings.wallpaperBlur || 0}
            onChange={(e) => updateSettings({ wallpaperBlur: Number(e.target.value) })}
            className="w-full h-2 bg-slate-200 dark:bg-white/10 rounded-full appearance-none cursor-pointer accent-blue-500"
          />
        </div>

        {/* Home Screen Layout */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 px-1">
            <LayoutGrid size={16} className="text-orange-500" />
            <h4 className="text-[10px] font-black uppercase tracking-[0.25em] text-slate-500 dark:text-slate-400">{t('home_screen')}</h4>
          </div>
          <div className="bg-white dark:bg-[#151515] rounded-[2rem] border border-slate-200 dark:border-white/5 overflow-hidden">
             <div className="flex items-center justify-between p-5 hover:bg-slate-50 dark:hover:bg-white/5 transition-colors">
                <div className="flex items-center gap-4">
                  <div className="p-2 bg-slate-100 dark:bg-white/5 rounded-xl text-slate-500 dark:text-slate-400">
                    <LayoutGrid size={18} />
                  </div>
                  <span className="text-[11px] font-bold uppercase text-slate-700 dark:text-slate-200 tracking-wider">{t('speed_dials')}</span>
                </div>
                <button 
                  onClick={() => updateSettings({ showSpeedDial: !settings.showSpeedDial })}
                  className="text-slate-300 dark:text-slate-600 hover:text-dragon-ember dark:hover:text-dragon-ember transition-colors"
                >
                  {settings.showSpeedDial ? <ToggleRight size={32} className="text-dragon-ember" /> : <ToggleLeft size={32} />}
                </button>
             </div>
          </div>
        </div>

        {/* Toolbar Config */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 px-1">
            <Layout size={16} className="text-purple-500" />
            <h4 className="text-[10px] font-black uppercase tracking-[0.25em] text-slate-500 dark:text-slate-400">{t('toolbar_layout')}</h4>
          </div>
          <div className="bg-white dark:bg-[#151515] rounded-[2rem] border border-slate-200 dark:border-white/5 overflow-hidden">
            {[
              { id: 'showLens', label: t('google_lens'), icon: <Camera size={18} /> },
              { id: 'showMic', label: t('voice_search'), icon: <Mic size={18} /> },
              { id: 'showNotes', label: t('quick_notes'), icon: <Pencil size={18} /> },
              { id: 'showDesktopMode', label: t('desktop_mode'), icon: <Monitor size={18} /> },
              { id: 'showBookmark', label: t('bookmarks'), icon: <Star size={18} /> },
              { id: 'showNewTab', label: t('new_tab'), icon: <Plus size={18} /> },
            ].map((tool, idx) => (
              <div key={tool.id} className={`flex items-center justify-between p-5 hover:bg-slate-50 dark:hover:bg-white/5 transition-colors ${idx !== 5 ? 'border-b border-slate-100 dark:border-white/5' : ''}`}>
                <div className="flex items-center gap-4">
                  <div className="p-2 bg-slate-100 dark:bg-white/5 rounded-xl text-slate-500 dark:text-slate-400">
                    {tool.icon}
                  </div>
                  <span className="text-[11px] font-bold uppercase text-slate-700 dark:text-slate-200 tracking-wider">{tool.label}</span>
                </div>
                <button 
                  onClick={() => handleToolbarToggle(tool.id as keyof ToolbarConfig)}
                  className="text-slate-300 dark:text-slate-600 hover: