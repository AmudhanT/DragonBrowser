import React, { useRef, useState, useEffect } from 'react';
import { useDragon } from '../DragonContext';
import DragonHeader from '../components/DragonHeader';
import { 
  Palette, Search, Check, Monitor, 
  ChevronRight, Zap, Fingerprint, Lock, ShieldCheck,
  Download, Upload, Send, Mail, ShieldAlert,
  Clock, Trash2, LayoutGrid, Sun, Moon,
  Info, Mic, Pencil, FolderOpen, Heart, AlertTriangle,
  Globe, Server, Sparkles, Star, Layers, Plus, Image as ImageIcon, Code, BellOff,
  MapPin, Camera, Video, Bell, HardDrive
} from 'lucide-react';
import { SearchEngine, AppSettings, BrowserViewMode, ToolbarConfig, ThemeColor, SystemPermissions } from '../types';
import { AppLockScreen } from '../components/AppLockScreen';
import { App as CapacitorApp } from '@capacitor/app';

type SettingsPage = 'MAIN' | 'GENERAL' | 'PRIVACY' | 'STORAGE' | 'ABOUT' | 'PERMISSIONS';

export const Settings: React.FC = () => {
  const { settings, updateSettings, clearHistory, setViewMode, architect, requestSystemPermission } = useDragon();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const wallpaperInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);
  
  const [currentView, setCurrentView] = useState<SettingsPage>('MAIN');
  const [searchQuery, setSearchQuery] = useState('');
  const [showPinSetup, setShowPinSetup] = useState(false);
  
  const handleToggle = (key: keyof AppSettings) => {
    updateSettings({ [key]: !settings[key] });
  };

  const handleToolbarToggle = (key: keyof ToolbarConfig) => {
    updateSettings({
      toolbarConfig: {
        ...settings.toolbarConfig,
        [key]: !settings.toolbarConfig[key]
      }
    });
  };

  const handleAppLockToggle = () => {
    if (settings.security.appLockEnabled) {
      // Disable
      updateSettings({
        security: { ...settings.security, appLockEnabled: false }
      });
    } else {
      // Enable -> Show Setup
      setShowPinSetup(true);
    }
  };

  const handlePinSetupComplete = (pin: string) => {
    updateSettings({
      security: {
        ...settings.security,
        appLockEnabled: true,
        pin: pin
      }
    });
    setShowPinSetup(false);
  };

  // Search Logic
  const checkMatch = (keywords: string[]) => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return keywords.some(k => k.toLowerCase().includes(query));
  };

  const presets = [
    { id: 'default', name: 'Dragon Default', url: 'https://images.unsplash.com/photo-1614850523296-d8c1af93d400?q=80&w=1000' },
    { id: 'void', name: 'Void Black', url: '' },
    { id: 'cyber', name: 'Cyber Grid', url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=1000' },
    { id: 'abyssal', name: 'Abyssal Black', url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=1000' },
    { id: 'magma', name: 'Magma Flow', url: 'https://images.unsplash.com/photo-1518558997970-4ddc236affcd?q=80&w=1000' },
    { id: 'nebula', name: 'Cosmic Nebula', url: 'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?q=80&w=1000' },
    { id: 'zen', name: 'Zen Garden', url: 'https://images.unsplash.com/photo-1528353518132-131198096b63?q=80&w=1000' },
    { id: 'grid', name: 'Retro Grid', url: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=1000' },
    { id: 'sky', name: 'Dream Sky', url: 'https://images.unsplash.com/photo-1499002238440-d264edd596ec?q=80&w=1000' },
    { id: 'tokyo', name: 'Neon Tokyo', url: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?q=80&w=1000' },
    { id: 'aurora', name: 'Northern Lights', url: 'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?q=80&w=1000' }
  ];

  const exportDragonConfig = () => {
    const config = JSON.stringify(localStorage);
    const blob = new Blob([config], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'dragon_config_v1.0.8A.json';
    link.click();
    URL.revokeObjectURL(url);
  };

  const importDragonConfig = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target?.result as string);
          Object.keys(data).forEach(key => localStorage.setItem(key, data[key]));
          alert("Dragon Browser: Infrastructure Restored. Restarting Engine...");
          window.location.reload();
        } catch (error) {
          alert("Invalid Config File Detected.");
        }
      };
      reader.readAsText(file);
    }
  };

  const handleWallpaperUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64Image = e.target?.result as string;
        updateSettings({ wallpaper: base64Image });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFolderSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      const path = `/Internal Storage/Downloads/${event.target.files[0].name.split('/')[0] || 'Custom'}`; 
      updateSettings({ downloadLocation: path });
    }
  };

  // --- PERMISSIONS RENDERER ---
  const renderPermissionsContent = () => (
    <div className="p-4 space-y-8 animate-fade-in">
      <div className="px-2 pb-2 border-b border-slate-100 dark:border-white/5">
        <p className="text-[10px] text-slate-500 font-medium italic">Manage Android system permissions granted to Dragon Browser.</p>
      </div>

      <div className="space-y-4">
        {[
          { key: 'camera', label: 'Camera Access', icon: <Camera size={16} />, desc: 'For QR codes and photo capture' },
          { key: 'microphone', label: 'Microphone', icon: <Mic size={16} />, desc: 'Voice Search & Audio recording' },
          { key: 'location', label: 'Location Services', icon: <MapPin size={16} />, desc: 'Geolocation for maps & local sites' },
          { key: 'notifications', label: 'Notifications', icon: <Bell size={16} />, desc: 'Download progress updates' },
          { key: 'storage', label: 'Media & Files', icon: <HardDrive size={16} />, desc: 'Access for Uploads & Downloads' },
        ].map((perm) => {
          const status = settings.systemPermissions[perm.key as keyof SystemPermissions];
          const isGranted = status === 'granted';
          
          return (
            <div key={perm.key} className="p-4 bg-white dark:bg-black/20 rounded-2xl border border-slate-200 dark:border-white/5 flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-4">
                <div className={`p-3 rounded-xl ${isGranted ? 'bg-green-500/10 text-green-500' : 'bg-slate-100 dark:bg-white/5 text-slate-400'}`}>
                  {perm.icon}
                </div>
                <div className="text-left">
                  <span className="text-xs font-black text-slate-700 dark:text-slate-200 uppercase tracking-tighter block">{perm.label}</span>
                  <span className="text-[9px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest">{perm.desc}</span>
                </div>
              </div>
              
              {isGranted ? (
                <div className="flex items-center gap-2 px-3 py-1.5 bg-green-500/10 rounded-lg border border-green-500/20">
                  <span className="text-[8px] font-black text-green-500 uppercase tracking-widest">Allowed</span>
                  <Check size={10} className="text-green-500" strokeWidth={3} />
                </div>
              ) : (
                <button
                  onClick={() => requestSystemPermission(perm.key as keyof SystemPermissions)}
                  className="px-4 py-2 bg-dragon-ember hover:bg-orange-600 text-white rounded-xl text-[9px] font-black uppercase tracking-widest transition-all active:scale-95 shadow-lg shadow-dragon-ember/20"
                >
                  Enable
                </button>
              )}
            </div>
          );
        })}
      </div>
      
      <div className="p-4 bg-blue-50 dark:bg-blue-500/10 rounded-2xl border border-blue-200 dark:border-blue-500/20 flex items-start gap-3 mt-4">
         <Info size={16} className="text-blue-500 shrink-0 mt-0.5" />
         <div>
           <p className="text-[10px] font-black text-blue-600 dark:text-blue-400 uppercase tracking-widest mb-1">On-Demand Security</p>
           <p className="text-[10px] text-slate-600 dark:text-slate-400 leading-relaxed font-medium">
             Dragon Browser only requests permissions when you actively use a feature. You can revoke these at any time in your Android System Settings.
           </p>
         </div>
      </div>
    </div>
  );

  const renderGeneralContent = () => (
    <div className="p-4 space-y-10 animate-fade-in">
      {/* ... existing General content ... */}
      <div className="px-2 pb-2 border-b border-slate-100 dark:border-white/5">
        <p className="text-[10px] text-slate-500 font-medium italic">Customize search engines, themes, and interface essence.</p>
      </div>

      {/* SEARCH ENGINES */}
      {checkMatch(['search', 'engine', 'google', 'bing', 'dragon']) && (
      <div className="space-y-4">
        <div className="flex items-center gap-2 mb-2 px-2">
            <Globe size={14} className="text-slate-400" />
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Search Intelligence</span>
        </div>
        <div className="grid grid-cols-1 gap-3">
          {[
            { id: 'dragon', label: 'Dragon Engine', color: 'text-dragon-ember' },
            { id: 'google', label: 'Google Global', color: 'text-blue-500' },
            { id: 'bing', label: 'Microsoft Bing', color: 'text-cyan-500' },
          ].map((engine) => (
            <button
              key={engine.id}
              onClick={() => updateSettings({ searchEngine: engine.id as SearchEngine })}
              className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${
                settings.searchEngine === engine.id 
                ? 'bg-white dark:bg-white/10 border-slate-200 dark:border-white/20 shadow-lg' 
                : 'bg-white/50 dark:bg-white/5 border-transparent opacity-80'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center bg-white/5 ${engine.color}`}>
                  <Search size={16} />
                </div>
                <span className={`text-xs font-black uppercase tracking-tight ${engine.color}`}>
                  {engine.label}
                </span>
              </div>
              {settings.searchEngine === engine.id && <Check size={16} className="text-dragon-ember" />}
            </button>
          ))}
        </div>
      </div>
      )}

      {/* VISUAL & APPEARANCE */}
      {checkMatch(['theme', 'dark', 'light', 'system', 'visual', 'appearance']) && (
      <div className="space-y-4">
          <div className="flex items-center gap-2 mb-2 px-2">
            <Palette size={14} className="text-slate-400" />
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Visual Appearance</span>
          </div>
          
          <div className="grid grid-cols-3 gap-2 bg-white dark:bg-black/40 p-2 rounded-2xl border border-slate-200 dark:border-white/5 mb-3">
            {[
              { id: 'system', label: 'System', icon: <Monitor size={14} /> },
              { id: 'light', label: 'Light', icon: <Sun size={14} /> },
              { id: 'dark', label: 'Dark', icon: <Moon size={14} /> }
            ].map((mode) => (
                <button
                key={mode.id}
                onClick={() => updateSettings({ themeMode: mode.id as any })}
                className={`
                  flex items-center justify-center gap-2 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all
                  ${settings.themeMode === mode.id 
                    ? 'bg-slate-100 dark:bg-dragon-navy text-dragon-ember shadow-sm border border-slate-200 dark:border-white/10' 
                    : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}
                `}
                >
                  {mode.icon} {mode.label}
                </button>
            ))}
          </div>
      </div>
      )}

      {/* WALLPAPER */}
      {checkMatch(['wallpaper', 'background', 'image', 'upload']) && (
      <div className="space-y-4">
          <div className="flex items-center gap-2 mb-2 px-2">
            <ImageIcon size={14} className="text-slate-400" />
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Wallpapers</span>
          </div>

          <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4 px-1 snap-x">
            <button
              onClick={() => wallpaperInputRef.current?.click()}
              className="relative shrink-0 w-24 h-24 rounded-2xl border-2 border-dashed border-slate-300 dark:border-white/20 flex flex-col items-center justify-center gap-2 hover:border-dragon-cyan hover:bg-dragon-cyan/5 transition-all group snap-start bg-white/50 dark:bg-white/5"
            >
              <div className="p-2 bg-slate-100 dark:bg-white/5 rounded-full group-hover:bg-dragon-cyan/20 group-hover:text-dragon-cyan transition-colors">
                  <Upload size={16} className="text-slate-400 dark:text-slate-500 group-hover:text-dragon-cyan" />
              </div>
              <span className="text-[8px] font-black text-slate-500 uppercase tracking-tighter group-hover:text-dragon-cyan">Select File</span>
            </button>
            <input type="file" ref={wallpaperInputRef} className="hidden" accept="image/*" onChange={handleWallpaperUpload} />

            {presets.map(preset => (
              <button
                key={preset.id}
                onClick={() => updateSettings({ wallpaper: preset.id })}
                className={`relative shrink-0 w-24 h-24 rounded-2xl border-2 transition-all overflow-hidden shadow-lg snap-start ${settings.wallpaper === preset.id ? 'border-dragon-ember scale-105 z-10 ring-2 ring-dragon-ember/30' : 'border-slate-200 dark:border-white/10 opacity-70 grayscale-[50%] hover:grayscale-0 hover:opacity-100'}`}
              >
                {preset.url ? (
                  <img src={preset.url} className="w-full h-full object-cover" alt={preset.name} />
                ) : (
                  <div className="w-full h-full bg-black flex items-center justify-center">
                    <span className="text-[7px] text-slate-500 font-mono">VOID</span>
                  </div>
                )}
                <div className="absolute inset-x-0 bottom-0 bg-black/60 backdrop-blur-sm py-1 px-2">
                    <span className="text-[7px] font-black text-white uppercase tracking-tighter truncate block">{preset.name}</span>
                </div>
                {settings.wallpaper === preset.id && (
                  <div className="absolute top-1 right-1 w-4 h-4 bg-dragon-ember rounded-full flex items-center justify-center shadow-lg">
                    <Check size={10} className="text-white" strokeWidth={3} />
                  </div>
                )}
              </button>
            ))}
          </div>
      </div>
      )}

      {/* TOOLBAR */}
      {checkMatch(['toolbar', 'interface', 'voice', 'mic', 'notes', 'desktop', 'find', 'bookmark', 'tabs']) && (
      <div className="space-y-4">
        <div className="flex items-center gap-2 mb-2 px-2">
            <LayoutGrid size={14} className="text-slate-400" />
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Interface Controls</span>
        </div>
        <div className="space-y-3">
          {[
            { label: 'Voice Search', key: 'showMic', icon: <Mic size={14} /> },
            { label: 'Quick Notes', key: 'showNotes', icon: <Pencil size={14} /> },
            { label: 'Desktop Toggle', key: 'showDesktopMode', icon: <Monitor size={14} /> },
            { label: 'Find In Page', key: 'showFind', icon: <Search size={14} /> },
            { label: 'New Tab Shortcut', key: 'showNewTab', icon: <Plus size={14} /> },
            { label: 'Bookmark Shortcut', key: 'showBookmark', icon: <Star size={14} /> },
            { label: 'Tab Counter', key: 'showTabs', icon: <Layers size={14} /> },
          ].filter(item => checkMatch([item.label, 'toolbar', 'interface'])).map((item) => (
            <div key={item.key} className="flex items-center justify-between p-4 bg-white dark:bg-black/20 rounded-2xl border border-slate-200 dark:border-white/5 shadow-sm">
              <div className="flex items-center gap-3">
                <div className="text-slate-500 dark:text-slate-400 p-2 bg-slate-100 dark:bg-white/5 rounded-lg">{item.icon}</div>
                <span className="text-xs font-black text-slate-700 dark:text-slate-300 uppercase tracking-tight">{item.label}</span>
              </div>
              <button
                onClick={() => handleToolbarToggle(item.key as keyof ToolbarConfig)}
                className={`w-10 h-6 rounded-full relative transition-all shadow-inner ${settings.toolbarConfig[item.key as keyof ToolbarConfig] ? 'bg-dragon-cyan' : 'bg-slate-300 dark:bg-slate-800'}`}
              >
                <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow-md transition-all ${settings.toolbarConfig[item.key as keyof ToolbarConfig] ? 'translate-x-5' : 'translate-x-1'}`} />
              </button>
            </div>
          ))}
        </div>
      </div>
      )}
    </div>
  );

  const renderPrivacyContent = () => (
    <div className="p-4 space-y-8 animate-fade-in">
      <div className="px-2 pb-2 border-b border-slate-100 dark:border-white/5">
        <p className="text-[10px] text-slate-500 font-medium italic">Control how Dragon protects your identity.</p>
      </div>

      {/* APP LOCK */}
      {checkMatch(['lock', 'security', 'pin', 'biometric', 'app']) && (
        <div className="space-y-4">
          <div className="px-2 pt-2">
            <span className="text-[10px] font-black text-dragon-ember uppercase tracking-widest">Physical Security</span>
          </div>
          <div className="bg-white dark:bg-black/20 rounded-3xl p-6 border border-slate-200 dark:border-white/5 shadow-sm space-y-4">
             <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                   <div className={`p-2 rounded-xl ${settings.security.appLockEnabled ? 'bg-dragon-ember/20 text-dragon-ember' : 'bg-slate-100 dark:bg-white/5 text-slate-500'}`}>
                      <Lock size={18} />
                   </div>
                   <div className="text-left">
                      <span className="text-sm font-black text-slate-700 dark:text-slate-200 uppercase tracking-tight block">App Lock</span>
                      <span className="text-[9px] text-slate-500 font-bold uppercase tracking-widest">Biometric & PIN</span>
                   </div>
                </div>
                <button
                  onClick={handleAppLockToggle}
                  className={`w-12 h-7 rounded-full relative transition-all shadow-inner ${settings.security.appLockEnabled ? 'bg-dragon-ember' : 'bg-slate-300 dark:bg-slate-700'}`}
                >
                  <div className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow-xl transition-all ${settings.security.appLockEnabled ? 'translate-x-6' : 'translate-x-1'}`} />
                </button>
             </div>

             {settings.security.appLockEnabled && (
                <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-white/5">
                   <div className="flex items-center gap-3">
                      <Fingerprint size={16} className="text-slate-400" />
                      <span className="text-xs font-bold text-slate-600 dark:text-slate-300">Biometric Unlock</span>
                   </div>
                   <button
                    onClick={() => updateSettings({ security: { ...settings.security, biometricsEnabled: !settings.security.biometricsEnabled } })}
                    className={`w-10 h-6 rounded-full relative transition-all shadow-inner ${settings.security.biometricsEnabled ? 'bg-dragon-cyan' : 'bg-slate-300 dark:bg-slate-700'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow-xl transition-all ${settings.security.biometricsEnabled ? 'translate-x-5' : 'translate-x-1'}`} />
                  </button>
                </div>
             )}
          </div>
        </div>
      )}
      
      {/* HISTORY LINK */}
      {checkMatch(['history', 'log', 'data', 'access']) && (
      <div className="space-y-2">
        <div className="px-2">
          <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Data Access</span>
        </div>
        <button 
          onClick={() => setViewMode(BrowserViewMode.HISTORY)}
          className="w-full p-4 flex items-center justify-between bg-white dark:bg-dragon-navy/50 rounded-2xl border border-slate-200 dark:border-white/5 hover:bg-slate-50 dark:hover:bg-white/5 transition-all text-left group shadow-sm"
        >
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-xl bg-slate-100 dark:bg-black/40 border border-slate-200 dark:border-white/5 group-hover:bg-dragon-cyan/10 transition-colors">
              <Clock size={20} className="text-dragon-cyan" />
            </div>
            <div className="text-left">
              <span className="text-sm font-black text-slate-700 dark:text-slate-300 uppercase tracking-tighter block group-hover:text-dragon-cyan transition-colors">Dragon History</span>
              <span className="text-[10px] text-slate-400 dark:text-slate-600 font-bold uppercase tracking-widest">Temporal Registry</span>
            </div>
          </div>
          <ChevronRight size={18} className="text-slate-400 dark:text-slate-700 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
      )}

      {/* PROTECTION GROUP */}
      {checkMatch(['protection', 'shield', 'ad', 'block', 'tracker', 'fingerprint', 'malware', 'javascript', 'script']) && (
      <div className="space-y-4">
        <div className="px-2 pt-2">
          <span className="text-[10px] font-black text-dragon-cyan uppercase tracking-widest">Protection Layer</span>
        </div>
        <div className="space-y-3">
          {[
            { label: 'Ad & Script Blocker', key: 'dragonBreath', icon: <Zap size={16} />, desc: 'Stop intrusive trackers' },
            { label: 'Anti-Fingerprinting', key: 'stealthFlight', icon: <Fingerprint size={16} />, desc: 'Mask device identity' },
            { label: 'Malware Protection', key: 'safeBrowsing', icon: <ShieldCheck size={16} />, desc: 'Block harmful nodes' },
            { label: 'JavaScript Execution', key: 'javaScriptEnabled', icon: <Code size={16} />, desc: 'Allow sites to run scripts' },
          ].filter(item => checkMatch([item.label, item.desc, 'protection', 'shield', 'javascript'])).map((item) => (
            <div key={item.key} className="p-4 rounded-2xl bg-white dark:bg-black/20 border border-slate-200 dark:border-white/5 flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-xl ${settings[item.key as keyof AppSettings] ? 'text-dragon-ember bg-dragon-ember/5' : 'text-slate-400 dark:text-slate-600 bg-slate-100 dark:bg-white/5'}`}>
                  {item.icon}
                </div>
                <div className="text-left">
                  <span className="text-xs font-black text-slate-700 dark:text-slate-200 uppercase tracking-tighter block">{item.label}</span>
                  <span className="text-[8px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest">{item.desc}</span>
                </div>
              </div>
              <button
                onClick={() => handleToggle(item.key as keyof AppSettings)}
                className={`w-10 h-6 rounded-full relative transition-all shadow-inner ${settings[item.key as keyof AppSettings] ? 'bg-dragon-ember' : 'bg-slate-300 dark:bg-slate-700'}`}
              >
                <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow-xl transition-all ${settings[item.key as keyof AppSettings] ? 'translate-x-5' : 'translate-x-1'}`} />
              </button>
            </div>
          ))}
        </div>
      </div>
      )}

      {/* ACCESS GROUP */}
      {checkMatch(['access', 'lock', 'secure', 'private', 'incognito']) && (
      <div className="space-y-4">
        <div className="px-2 pt-2">
          <span className="text-[10px] font-black text-purple-500 uppercase tracking-widest">Access Control</span>
        </div>
        <div className="p-4 rounded-2xl bg-white dark:bg-black/20 border border-slate-200 dark:border-white/5 flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-xl ${settings.incognitoLockEnabled ? 'text-purple-500 bg-purple-500/10' : 'text-slate-400 dark:text-slate-600 bg-slate-100 dark:bg-white/5'}`}>
                <Lock size={16} />
              </div>
              <div className="text-left">
                <span className="text-xs font-black text-slate-700 dark:text-slate-200 uppercase tracking-tighter block">Secure Private Tabs</span>
                <span className="text-[8px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest">Biometric Lock</span>
              </div>
            </div>
            <button
              onClick={() => handleToggle('incognitoLockEnabled')}
              className={`w-10 h-6 rounded-full relative transition-all shadow-inner ${settings.incognitoLockEnabled ? 'bg-purple-500' : 'bg-slate-300 dark:bg-slate-700'}`}
            >
              <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow-xl transition-all ${settings.incognitoLockEnabled ? 'translate-x-5' : 'translate-x-1'}`} />
            </button>
        </div>
      </div>
      )}

      {/* DANGER ZONE */}
      {checkMatch(['danger', 'clear', 'wipe', 'delete', 'remove', 'history']) && (
      <div className="p-4 bg-red-50/50 dark:bg-red-500/5 border border-red-100 dark:border-red-500/20 rounded-3xl mt-4">
          <div className="px-2 mb-3">
              <span className="text-[10px] font-black text-red-500 uppercase tracking-widest flex items-center gap-2">
                  <AlertTriangle size={12} /> Danger Zone
              </span>
          </div>
          <button 
            onClick={() => { 
              if (window.confirm('This action cannot be undone. Wipe all browsing history?')) {
                clearHistory(); 
              }
            }}
            className="w-full p-4 flex items-center gap-3 bg-white dark:bg-black/20 hover:bg-red-50 dark:hover:bg-red-500/10 text-red-600 dark:text-red-400 transition-all border border-red-200 dark:border-red-500/20 rounded-2xl shadow-[0_0_15px_rgba(239,68,68,0.1)] group"
          >
            <div className="p-2 bg-red-100 dark:bg-red-500/10 rounded-lg group-hover:bg-red-200 dark:group-hover:bg-red-500/20 transition-colors">
                <Trash2 size={18} />
            </div>
            <div className="text-left">
              <span className="text-xs font-black uppercase tracking-tighter block">Clear History Registry</span>
              <span className="text-[9px] font-bold uppercase tracking-widest opacity-70">Irreversible Action</span>
            </div>
          </button>
      </div>
      )}
    </div>
  );

  const renderStorageContent = () => (
    <div className="p-4 space-y-8 animate-fade-in">
      <div className="px-2 pb-2 border-b border-slate-100 dark:border-white/5">
        <p className="text-[10px] text-slate-500 font-medium italic">Manage storage locations and configuration backups.</p>
      </div>

      {/* DOWNLOAD PATH SELECTOR */}
      {checkMatch(['storage', 'download', 'path', 'folder', 'location']) && (
      <div className="space-y-4">
        <div className="px-2">
          <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Path Configuration</span>
        </div>
        <button 
          onClick={() => folderInputRef.current?.click()}
          className="w-full text-left p-6 bg-white dark:bg-dragon-navy/50 rounded-2xl border border-slate-200 dark:border-white/5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-white/5 transition-colors group shadow-sm"
        >
          <div className="flex-1 min-w-0">
            <span className="text-xs font-black text-slate-700 dark:text-slate-300 uppercase tracking-tighter block group-hover:text-dragon-cyan transition-colors">Download Path</span>
            <span className="text-[9px] text-slate-400 dark:text-slate-600 font-mono truncate block mt-1">{settings.downloadLocation}</span>
          </div>
          <FolderOpen className="text-slate-500 group-hover:text-dragon-cyan w-5 h-5" />
        </button>
        <input 
          type="file" 
          ref={folderInputRef}
          className="hidden" 
          {...({ webkitdirectory: "", directory: "" } as any)}
          onChange={handleFolderSelect} 
        />
      </div>
      )}

      {/* NOTIFICATIONS TOGGLE */}
      {checkMatch(['notification', 'sound', 'quiet', 'mute']) && (
      <div className="space-y-2">
        <div className="p-4 bg-white dark:bg-black/20 rounded-2xl border border-slate-200 dark:border-white/5 flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-xl ${settings.muteDownloadNotifications ? 'text-orange-500 bg-orange-500/10' : 'text-slate-400 dark:text-slate-600 bg-slate-100 dark:bg-white/5'}`}>
                <BellOff size={16} />
              </div>
              <div className="text-left">
                <span className="text-xs font-black text-slate-700 dark:text-slate-200 uppercase tracking-tighter block">Quiet Downloads</span>
                <span className="text-[8px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest">Disable notification sounds</span>
              </div>
            </div>
            <button
              onClick={() => handleToggle('muteDownloadNotifications')}
              className={`w-10 h-6 rounded-full relative transition-all shadow-inner ${settings.muteDownloadNotifications ? 'bg-orange-500' : 'bg-slate-300 dark:bg-slate-700'}`}
            >
              <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow-xl transition-all ${settings.muteDownloadNotifications ? 'translate-x-5' : 'translate-x-1'}`} />
            </button>
        </div>
      </div>
      )}

      {checkMatch(['backup', 'restore', 'export', 'import', 'config']) && (
      <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-white/5">
        <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest block text-center opacity-70">
          Backup & Recovery
        </span>
        <div className="flex gap-3">
          <button onClick={exportDragonConfig} className="flex-1 flex items-center justify-center gap-2 py-5 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10 rounded-2xl text-[9px] font-black uppercase tracking-widest transition-all shadow-sm">
            <Download size={16} /> Backup Settings
          </button>
          <button onClick={() => fileInputRef.current?.click()} className="flex-1 flex items-center justify-center gap-2 py-5 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10 rounded-2xl text-[9px] font-black uppercase tracking-widest transition-all shadow-sm">
            <Upload size={16} /> Restore Settings
          </button>
          <input type="file" ref={fileInputRef} className="hidden" accept=".json" onChange={importDragonConfig} />
        </div>
      </div>
      )}
    </div>
  );

  const renderAboutContent = () => (
    <div className="p-4 space-y-8 animate-fade-in">
      <div className="px-2 pb-2 border-b border-slate-100 dark:border-white/5">
        <p className="text-[10px] text-slate-500 font-medium italic">Information about the build and developer contact.</p>
      </div>
      
      {/* Privacy Policy */}
      {checkMatch(['privacy', 'policy', 'protocol']) && (
      <div className="space-y-3">
        <div className="flex items-center gap-3 px-2">
          <ShieldAlert size={16} className="text-dragon-cyan" />
          <span className="text-xs font-black text-slate-700 dark:text-slate-200 uppercase tracking-tighter">Privacy Protocol</span>
        </div>
        <div className="bg-white dark:bg-black/20 rounded-3xl p-6 border border-slate-200 dark:border-white/5 space-y-4 shadow-sm">
          <p className="text-[10px] text-slate-600 dark:text-slate-400 font-medium leading-relaxed">
            Dragon Browser is designed with privacy as the core principle. We do not collect, track, store, or sell any personal information. All browsing activity remains locally on your device.
          </p>
          <div className="space-y-2">
              {[
                'Zero Data Collection',
                'Local History Only',
                'No Tracking or Analytics',
                'User-First Approach'
              ].map(item => (
                <div key={item} className="flex items-center gap-2">
                  <div className="w-1 h-1 bg-dragon-cyan rounded-full" />
                  <span className="text-[9px] font-bold text-slate-500 dark:text-slate-500 uppercase tracking-widest">{item}</span>
                </div>
              ))}
          </div>
        </div>
      </div>
      )}

      {/* Feedback & Support */}
      {checkMatch(['feedback', 'support', 'contact', 'email']) && (
      <div className="space-y-3">
        <div className="flex items-center gap-3 px-2">
          <Mail size={16} className="text-dragon-ember" />
          <span className="text-xs font-black text-slate-700 dark:text-slate-200 uppercase tracking-tighter">Feedback & Support</span>
        </div>
        <div className="bg-white dark:bg-black/20 rounded-3xl p-6 border border-slate-200 dark:border-white/5 space-y-4 shadow-sm">
          <p className="text-[10px] text-slate-600 dark:text-slate-400 font-medium leading-relaxed">
            Have suggestions, bugs, or feature requests? We’d love to hear from you.
          </p>
          <a 
            href="mailto:sgamudhan@gmail.com"
            className="flex items-center justify-center gap-2 w-full py-3 bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl text-[9px] font-black uppercase tracking-widest text-slate-700 dark:text-white hover:bg-dragon-ember hover:text-white hover:border-dragon-ember transition-all shadow-sm group"
          >
            <Send size={12} className="group-hover:translate-x-0.5 transition-transform" /> Send Feedback
          </a>
        </div>
      </div>
      )}

      {/* Version Info */}
      {checkMatch(['version', 'about']) && (
      <div className="p-6 text-center space-y-1 opacity-50 mt-8">
          <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Dragon Browser v1.0.8A</p>
          <p className="text-[9px] text-slate-600 uppercase font-bold tracking-widest flex items-center justify-center gap-1">Built with <Heart size={8} fill="currentColor" /> for privacy</p>
      </div>
      )}
    </div>
  );

  const renderMainMenu = () => (
    <div className="p-4 space-y-6 animate-fade-in">
      {/* Profile Card */}
      <div className="relative group mb-6">
        <div className="absolute -inset-1 bg-gradient-to-r from-dragon-ember to-dragon-cyan blur opacity-20 group-hover:opacity-40 transition-opacity rounded-[2rem]" />
        <div className="relative bg-white dark:bg-dragon-navy/50 rounded-[2rem] p-6 border border-slate-200 dark:border-white/10 shadow-xl flex items-center gap-6">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-dragon-ember to-slate-900 flex items-center justify-center text-2xl font-black text-white shadow-[0_10px_30px_rgba(249,115,22,0.3)] ring-4 ring-white dark:ring-black/20">
            AT
          </div>
          <div>
            <h3 className="text-lg font-black text-slate-900 dark:text-white tracking-tight">Amudhan T</h3>
            <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">Lead Browser Architect</p>
            <div className="flex gap-2 mt-2">
              <span className="px-2 py-0.5 bg-dragon-cyan/10 text-dragon-cyan text-[8px] font-black rounded-full border border-dragon-cyan/20 uppercase tracking-wide">PRO</span>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {[
          { id: 'GENERAL', label: 'General', desc: 'Theme, Search, Interface', icon: <Palette size={18} className="text-dragon-ember" />, view: 'GENERAL' },
          { id: 'PRIVACY', label: 'Privacy & Security', desc: 'App Lock, Protection', icon: <ShieldCheck size={18} className="text-dragon-cyan" />, view: 'PRIVACY' },
          { id: 'PERMISSIONS', label: 'System Permissions', desc: 'Camera, Mic, Location', icon: <Lock size={18} className="text-green-500" />, view: 'PERMISSIONS' },
          { id: 'STORAGE', label: 'Downloads', desc: 'Path, Backup, Restore', icon: <Download size={18} className="text-purple-500" />, view: 'STORAGE' },
          { id: 'ABOUT', label: 'About & Help', desc: 'Version, Policy, Support', icon: <Info size={18} className="text-slate-500" />, view: 'ABOUT' },
        ].map(item => (
          <button
            key={item.id}
            onClick={() => setCurrentView(item.view as SettingsPage)}
            className="w-full p-5 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/5 rounded-[1.5rem] flex items-center justify-between group hover:bg-slate-50 dark:hover:bg-white/10 transition-all shadow-sm hover:shadow-lg hover:-translate-y-0.5"
          >
            <div className="flex items-center gap-5">
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-black/40 border border-slate-100 dark:border-white/5 group-hover:scale-110 transition-transform">
                {item.icon}
              </div>
              <div className="flex flex-col items-start">
                <span className="text-sm font-black text-slate-900 dark:text-slate-100 uppercase tracking-tighter">{item.label}</span>
                <span className="text-[9px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest mt-0.5">{item.desc}</span>
              </div>
            </div>
            <div className="p-2 rounded-full bg-slate-50 dark:bg-white/5 group-hover:bg-white dark:group-hover:bg-white/10 transition-colors">
               <ChevronRight size={16} className="text-slate-300 dark:text-slate-600 group-hover:text-dragon-cyan transition-colors" />
            </div>
          </button>
        ))}
      </div>

      <div className="pt-8 pb-16 flex flex-col items-center gap-4 text-center opacity-70">
        <div className="space-y-1">
          <p className="text-[11px] text-slate-600 dark:text-slate-400 font-mono tracking-widest uppercase italic">Dragon Browser • v1.0.8A</p>
          <p className="text-[9px] text-slate-400 dark:text-slate-600 font-medium tracking-wider">Fast • Secure • Private</p>
        </div>
      </div>
    </div>
  );

  const renderContent = () => {
    // If searching, bypass navigation and show all matching blocks flat
    if (searchQuery) {
       return (
         <div className="animate-fade-in pb-20">
            <div className="px-6 py-4 border-b border-slate-100 dark:border-white/5 bg-slate-50 dark:bg-black/20">
               <p className="text-[10px] font-black text-dragon-cyan uppercase tracking-widest">Search Results</p>
            </div>
            {renderGeneralContent()}
            {renderPrivacyContent()}
            {renderPermissionsContent()}
            {renderStorageContent()}
            {renderAboutContent()}
         </div>
       );
    }

    switch(currentView) {
      case 'GENERAL': return renderGeneralContent();
      case 'PRIVACY': return renderPrivacyContent();
      case 'PERMISSIONS': return renderPermissionsContent();
      case 'STORAGE': return renderStorageContent();
      case 'ABOUT': return renderAboutContent();
      default: return renderMainMenu();
    }
  };

  const getHeaderTitle = () => {
    if (searchQuery) return "SEARCHING...";
    switch(currentView) {
      case 'GENERAL': return "GENERAL";
      case 'PRIVACY': return "PRIVACY";
      case 'PERMISSIONS': return "SYSTEM ACCESS";
      case 'STORAGE': return "DOWNLOADS";
      case 'ABOUT': return "ABOUT";
      default: return "SETTINGS";
    }
  };

  const handleBack = () => {
    if (searchQuery) {
      setSearchQuery('');
      return;
    }
    if (currentView === 'MAIN') {
      setViewMode(BrowserViewMode.BROWSER);
    } else {
      setCurrentView('MAIN');
    }
  };

  if (showPinSetup) {
    return (
      <AppLockScreen 
        isSetupMode={true} 
        onSetupComplete={handlePinSetupComplete} 
        onCancelSetup={() => setShowPinSetup(false)} 
      />
    );
  }

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-dragon-dark text-slate-900 dark:text-slate-100 overflow-hidden relative">
      
      <DragonHeader 
        title={getHeaderTitle()} 
        subtitle={currentView === 'MAIN' ? "SYSTEM CONTROL CENTER" : undefined}
        onBack={handleBack}
      />

      {/* SEARCH BAR (Only on Main or when searching) */}
      {(currentView === 'MAIN' || searchQuery) && (
        <div className="px-4 pb-2 pt-2 bg-slate-50 dark:bg-dragon-dark/95 backdrop-blur-xl transition-all z-40">
          <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-slate-500 group-focus-within:text-dragon-cyan transition-colors" />
            <input
              type="text"
              placeholder="Search settings..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white dark:bg-dragon-navy/50 border border-slate-200 dark:border-white/10 rounded-2xl py-3 pl-11 pr-4 text-sm font-medium focus:outline-none focus:border-dragon-cyan/50 focus:shadow-[0_0_15px_rgba(6,182,212,0.1)] transition-all placeholder-slate-400 dark:placeholder-slate-600 text-slate-900 dark:text-white"
            />
          </div>
        </div>
      )}

      <div className="flex-1 overflow-y-auto no-scrollbar pb-safe-bottom" key={currentView}>
        {renderContent()}
      </div>
    </div>
  );
};