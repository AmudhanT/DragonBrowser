
import React from 'react';
import { useDragon } from '../DragonContext';
import DragonHeader from '../components/DragonHeader';
import { DragonShield } from '../components/DragonShield';
import { BrowserViewMode } from '../types';

export const ShieldPage: React.FC = () => {
  const { settings, updateSettings, setViewMode } = useDragon();

  const handleToggleSetting = (key: any) => {
    updateSettings({ [key]: !settings[key as keyof typeof settings] });
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-dragon-dark text-slate-900 dark:text-slate-100 animate-fade-in pb-safe-bottom transition-colors duration-300">
      <DragonHeader 
        title="DRAGON SHIELD" 
        subtitle="PROTECTION PROTOCOLS" 
        onBack={() => setViewMode(BrowserViewMode.BROWSER)} 
      />

      <div className="flex-1 overflow-y-auto p-6 space-y-6 no-scrollbar">
        <div className="max-w-md mx-auto py-4">
            <DragonShield 
                settings={settings} 
                active={settings.adBlockEnabled}
                onToggleSetting={handleToggleSetting}
                currentUrl={""} // Active tab logic can be handled in App or Context
            />
        </div>

        <div className="max-w-md mx-auto bg-white dark:bg-dragon-navy/40 border border-slate-200 dark:border-white/5 rounded-[2rem] p-6 space-y-4 shadow-xl transition-colors duration-300">
            <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] border-l-2 border-dragon-cyan pl-3">Technical Overview</h3>
            <p className="text-[11px] text-slate-600 dark:text-slate-400 font-medium leading-relaxed italic">
                Dragon Shield utilizes a multi-layer heuristic engine to intercept malicious scripts before they reach the execution pipeline. Your identity is masked via stealth-flight obfuscation.
            </p>
            <div className="pt-2">
                <div className="flex justify-between items-center py-3 border-b border-slate-100 dark:border-white/5">
                    <span className="text-[10px] font-black text-slate-700 dark:text-slate-300 uppercase">Core Version</span>
                    <span className="text-[10px] font-mono text-dragon-cyan">v2.4.0-STRIKE</span>
                </div>
                <div className="flex justify-between items-center py-3">
                    <span className="text-[10px] font-black text-slate-700 dark:text-slate-300 uppercase">Encryption Level</span>
                    <span className="text-[10px] font-mono text-dragon-ember">AES-256-GCM</span>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};
