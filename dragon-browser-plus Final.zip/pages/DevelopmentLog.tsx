
import React from 'react';
import { useDragon } from '../DragonContext';
import DragonHeader from '../components/DragonHeader';
import { ScrollText, Sparkles, Zap, Shield, Rocket, Palette, Globe } from 'lucide-react';
import { BrowserViewMode } from '../types';

export const DevelopmentLog: React.FC = () => {
  const { setViewMode, architect } = useDragon();

  const logs = [
    {
      version: 'v1.0.8A',
      status: 'Current',
      icon: <Rocket className="w-4 h-4 text-dragon-ember" />,
      content: 'Integrated Downloads module with categorized filters, search, and native sharing. Refined UI animations and system-wide performance optimizations.'
    },
    {
      version: 'v1.0.7',
      status: 'Stable',
      icon: <Palette className="w-4 h-4 text-dragon-cyan" />,
      content: 'Finalized branding with custom Dragon Logo in Omnibar and center screen. Updated visual assets and theme consistency across all views.'
    },
    {
      version: 'v1.0.5',
      status: 'Legacy',
      icon: <Shield className="w-4 h-4 text-dragon-ember" />,
      content: 'Implemented Dragon Shield with Incognito mode tabs Lock and Ad-Blocker logic. Enhanced privacy masking and anti-fingerprinting protocols.'
    },
    {
      version: 'v1.0.2',
      status: 'Legacy',
      icon: <Sparkles className="w-4 h-4 text-blue-400" />,
      content: 'Added Voice Search, Google Suggestions, and Trending Search logic. Integrated initial AI summary features using Dragon Neural Core.'
    },
    {
      version: 'v1.0.0',
      status: 'Foundation',
      icon: <Globe className="w-4 h-4 text-slate-500" />,
      content: 'Initial build with circular Speed Dial icons and "Recent Most Viewed" logic. Core browser engine framework and tab management system established.'
    }
  ];

  return (
    <div className="flex flex-col h-full bg-dragon-dark text-slate-100 animate-fade-in pb-safe-bottom">
      <DragonHeader 
        title="DEVELOPMENT LOG" 
        subtitle="ARCHITECTURAL CHRONICLES" 
        onBack={() => setViewMode(BrowserViewMode.SETTINGS)}
        rightElement={
          <div className="p-2 bg-dragon-ember/10 rounded-xl border border-dragon-ember/20">
            <ScrollText size={18} className="text-dragon-ember" />
          </div>
        }
      />

      <div className="p-6 space-y-8 flex-1 overflow-y-auto no-scrollbar">
        {logs.map((log, idx) => (
          <div key={log.version} className="relative group">
            {idx !== logs.length - 1 && (
              <div className="absolute top-10 left-[21px] bottom-[-24px] w-0.5 bg-gradient-to-b from-dragon-ember/30 to-transparent" />
            )}
            <div className="flex gap-6 items-start">
              <div className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 shadow-lg border transition-all ${idx === 0 ? 'bg-dragon-ember/20 border-dragon-ember/30' : 'bg-black/40 border-white/5'}`}>
                {log.icon}
              </div>
              <div className="flex-1 space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="font-mono text-lg font-black tracking-tighter text-white">
                    {log.version}
                  </h3>
                  <span className={`text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest ${idx === 0 ? 'bg-dragon-ember text-white' : 'bg-white/5 text-slate-500'}`}>
                    {log.status}
                  </span>
                </div>
                <div className="bg-dragon-navy/40 p-5 rounded-[1.5rem] border border-white/5 shadow-xl group-hover:bg-white/5 transition-all">
                  <p className="text-xs text-slate-400 leading-relaxed font-medium">
                    {log.content}
                  </p>
                </div>
              </div>
            </div>
          </div>
        ))}

        <div className="pt-12 text-center space-y-6">
          <div className="flex flex-col items-center">
            <h4 className="text-dragon-ember text-[10px] font-black tracking-[0.5em] uppercase">Fast • Secure • Private</h4>
            <div className="mt-4 p-4 bg-white/5 rounded-2xl border border-white/5 inline-block opacity-40">
              <p className="text-[8px] text-slate-500 font-black uppercase tracking-widest">Architect: {architect}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
