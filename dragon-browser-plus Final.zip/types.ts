
export interface TabGroup {
  id: string;
  title: string;
  color: string;
  createdAt: number;
}

export interface Tab {
  id: string;
  url: string;
  title: string;
  favicon?: string;
  lastAccessed: number;
  isLoading: boolean;
  isPrivate: boolean;
  isHibernating?: boolean;
  history: string[];
  currentIndex: number;
  groupId?: string;
  renderId?: number;
}

export interface HistoryItem {
  id: string;
  url: string;
  title: string;
  timestamp: number;
}

export interface Bookmark {
  id: string;
  url: string;
  title: string;
  timestamp: number;
}

export interface NoteItem {
  id: string;
  text: string;
  date: string;
}

export type DownloadPriority = 'high' | 'normal' | 'low';

export interface DownloadItem {
  id: string;
  filename: string;
  url: string;
  size: string; // Formatted size string (e.g. "5.2 MB")
  totalBytes: number;
  receivedBytes: number;
  speed: string;
  type: 'image' | 'video' | 'audio' | 'pdf' | 'document' | 'other' | 'archive' | 'apk';
  timestamp: number;
  progress: number;
  status: 'completed' | 'downloading' | 'paused' | 'failed' | 'canceled' | 'queued';
  resumable?: boolean;
  priority: DownloadPriority;
  queueIndex: number;
}

export interface ActiveMedia {
  url: string;
  filename: string;
  type: 'video' | 'audio' | 'image';
}

export interface Language {
  code: string;
  name: string;
}

export enum BrowserViewMode {
  BROWSER = 'BROWSER',
  TAB_SWITCHER = 'TAB_SWITCHER',
  SETTINGS = 'SETTINGS',
  HISTORY = 'HISTORY',
  DOWNLOADS = 'DOWNLOADS',
  BOOKMARKS = 'BOOKMARKS',
  DEVELOPMENT_LOG = 'DEVELOPMENT_LOG',
  NOTES_LIBRARY = 'NOTES_LIBRARY',
  SHIELD = 'SHIELD',
  LIBRARY = 'LIBRARY'
}

export type ThemeMode = 'dark' | 'light' | 'system';
export type ThemeColor = 'ember' | 'frost' | 'midas' | 'venom';
export type SearchEngine = 'google' | 'bing' | 'dragon';

export interface ToolbarConfig {
  showFind: boolean;
  showTranslate: boolean;
  showMic: boolean;
  showNewTab: boolean;
  showNotes: boolean;
  showDesktopMode: boolean;
  showBookmark: boolean;
  showTabs: boolean;
}

export interface SecurityConfig {
  appLockEnabled: boolean;
  pin: string | null; // Encrypted or simple hash in real app, plain for this demo
  biometricsEnabled: boolean;
  lockTimeout: number; // in milliseconds
}

export interface AppSettings {
  adBlockEnabled: boolean;
  javaScriptEnabled: boolean;
  dragonBreath: boolean;
  stealthFlight: boolean;
  autoPurge: boolean;
  scaleCompression: boolean;
  isDesktopMode: boolean;
  searchEngine: SearchEngine;
  themeMode: ThemeMode;
  themeColor: ThemeColor;
  wallpaper: string;
  historyEnabled: boolean;
  doNotTrack: boolean;
  safeBrowsing: boolean;
  secureDns: boolean;
  incognitoLockEnabled: boolean;
  downloadLocation: string;
  muteDownloadNotifications: boolean;
  pipEnabled: boolean;
  floatingFeaturesEnabled: boolean;
  trackersBlockedTotal: number;
  sovereigntyMode: boolean; 
  toolbarConfig: ToolbarConfig;
  security: SecurityConfig;
}

export interface SitePermissions {
  javascript: boolean;
  cookies: boolean;
  location: boolean;
  camera: boolean;
  microphone: boolean;
  popups: boolean;
  lastModified: number;
}
