
export interface TabGroup {
  id: string;
  title: string;
  color: string;
  createdAt: number;
}

export interface Tab {
  id: string;
  url: string;
  title: string;
  favicon?: string;
  lastAccessed: number;
  isLoading: boolean;
  isPrivate: boolean;
  isHibernating?: boolean;
  pinned?: boolean;
  history: string[];
  currentIndex: number;
  groupId?: string;
  renderId?: number;
}

export interface HistoryItem {
  id: string;
  url: string;
  title: string;
  timestamp: number;
}

export interface Bookmark {
  id: string;
  url: string;
  title: string;
  timestamp: number;
}

export interface NoteItem {
  id: string;
  text: string;
  date: string;
}

export interface SavedPage {
  id: string;
  url: string;
  title: string;
  filename: string;
  timestamp: number;
  size: number;
}

export type DownloadPriority = 'high' | 'normal' | 'low';

export interface DownloadItem {
  id: string;
  filename: string;
  url: string;
  size: string; // Formatted size string (e.g. "5.2 MB")
  totalBytes: number;
  receivedBytes: number;
  speed: string;
  type: 'image' | 'video' | 'audio' | 'pdf' | 'document' | 'other' | 'archive' | 'apk';
  timestamp: number;
  progress: number;
  status: 'completed' | 'downloading' | 'paused' | 'failed' | 'canceled' | 'queued';
  resumable?: boolean;
  priority: DownloadPriority;
  queueIndex: number;
}

export interface ActiveMedia {
  url: string;
  filename: string;
  type: 'video' | 'audio' | 'image';
}

export interface Language {
  code: string;
  name: string;
}

export enum BrowserViewMode {
  BROWSER = 'BROWSER',
  TAB_SWITCHER = 'TAB_SWITCHER',
  SETTINGS = 'SETTINGS',
  HISTORY = 'HISTORY',
  DOWNLOADS = 'DOWNLOADS',
  BOOKMARKS = 'BOOKMARKS',
  NOTES_LIBRARY = 'NOTES_LIBRARY',
  SHIELD = 'SHIELD',
  LIBRARY = 'LIBRARY',
  MAIN_MENU = 'MAIN_MENU'
}

export type SettingsPage = 'MAIN' | 'GENERAL' | 'PRIVACY' | 'STORAGE' | 'ABOUT' | 'APPEARANCE' | 'SITE_SETTINGS' | 'LANGUAGES';
export type SettingsSource = 'menu' | 'home' | 'internal';

export type ThemeMode = 'dark' | 'light' | 'system';
export type ThemeColor = 'ember' | 'frost' | 'midas' | 'venom';
export type SearchEngine = 'google' | 'bing' | 'dragon';
export type AutoCloseDuration = 'never' | '1day' | '3days' | '7days';

export interface ToolbarConfig {
  showLens: boolean;
  showTranslate: boolean;
  showMic: boolean;
  showNewTab: boolean;
  showNotes: boolean;
  showDesktopMode: boolean;
  showBookmark: boolean;
  showTabs: boolean;
}

export interface SecurityConfig {
  appLockEnabled: boolean;
  pin: string | null; // Encrypted or simple hash in real app, plain for this demo
  biometricsEnabled: boolean;
  lockTimeout: number; // in milliseconds
}

export type CookiePolicy = 'allow' | 'block' | 'block_third_party';

export interface AppSettings {
  adBlockEnabled: boolean;
  javaScriptEnabled: boolean;
  dragonBreath: boolean;
  stealthFlight: boolean;
  trackerBlockingEnabled: boolean;
  autoPurge: boolean;
  scaleCompression: boolean;
  isDesktopMode: boolean;
  searchEngine: SearchEngine;
  themeMode: ThemeMode;
  themeColor: ThemeColor;
  wallpaper: string;
  wallpaperBlur: number;
  historyEnabled: boolean;
  doNotTrack: boolean;
  safeBrowsing: boolean;
  secureDns: boolean;
  incognitoLockEnabled: boolean;
  downloadLocation: string;
  notificationsEnabled: boolean;
  muteDownloadNotifications: boolean;
  pullToRefreshEnabled: boolean;
  pipEnabled: boolean;
  floatingFeaturesEnabled: boolean;
  trackersBlockedTotal: number;
  sovereigntyMode: boolean; 
  showSpeedDial: boolean;
  toolbarConfig: ToolbarConfig;
  security: SecurityConfig;
  language: string;
  cookiePolicy: CookiePolicy;
  siteDataEnabled: boolean;
  httpsOnlyMode: boolean;
  allowMixedContent: boolean;
  imagesEnabled: boolean;
  autoplayEnabled: boolean;
  popupsEnabled: boolean;
  locationPermission: PermissionState;
  cameraPermission: PermissionState;
  microphonePermission: PermissionState;
  notificationsPermission: PermissionState;
  dataSaverEnabled: boolean;
  dataSaved: number;
  autoCloseTabs: AutoCloseDuration;
}

export type PermissionState = 'allow' | 'block' | 'ask';

export interface SitePermissions {
  javascript: boolean;
  cookies: boolean;
  images: boolean;
  autoplay: boolean;
  forceDarkMode: boolean; // New: Force Dark Mode
  location: PermissionState;
  camera: PermissionState;
  microphone: PermissionState;
  notifications: PermissionState;
  media: PermissionState; // Photos & Videos
  sound: PermissionState;
  clipboard: PermissionState;
  popups: PermissionState;
  lastModified: number;
}

export interface ImageContextData {
  url: string;
}
