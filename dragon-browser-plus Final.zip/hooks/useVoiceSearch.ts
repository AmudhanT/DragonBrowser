
import { useState, useCallback, useRef, useEffect } from 'react';

export type VoiceState = 'idle' | 'listening' | 'processing' | 'error' | 'success';

// Define the Global Interface for the Android Native Bridge
declare global {
  interface Window {
    DragonBridge?: {
      startVoiceRecognition: () => void;
    };
    // Callbacks invoked by Android Native Code
    onVoiceRecognitionResult?: (text: string) => void;
    onVoiceRecognitionError?: (error: string) => void;
  }
}

export const useVoiceSearch = (onResult: (text: string) => void) => {
  const [voiceState, setVoiceState] = useState<VoiceState>('idle');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [error, setError] = useState<string | null>(null);
  
  const onResultRef = useRef(onResult);

  useEffect(() => {
    onResultRef.current = onResult;
  }, [onResult]);

  // Setup listeners for Android Native Events
  useEffect(() => {
    window.onVoiceRecognitionResult = (text: string) => {
      setVoiceState('success');
      setInterimTranscript(text);
      
      // Execute the callback with the recognized text
      if (onResultRef.current) {
        onResultRef.current(text);
      }

      // Auto-reset state after a brief success display
      setTimeout(() => {
        setVoiceState('idle');
        setInterimTranscript('');
      }, 800);
    };

    window.onVoiceRecognitionError = (errorMessage: string) => {
      console.warn("Voice Error:", errorMessage);
      setVoiceState('error');
      setError(errorMessage);
      
      // Auto-reset error state
      setTimeout(() => {
        setVoiceState('idle');
        setError(null);
      }, 2500);
    };

    return () => {
      // Clean up global handlers to prevent memory leaks or zombie calls
      window.onVoiceRecognitionResult = undefined;
      window.onVoiceRecognitionError = undefined;
    };
  }, []);

  const startListening = useCallback(() => {
    if (window.DragonBridge && window.DragonBridge.startVoiceRecognition) {
      setVoiceState('listening');
      setInterimTranscript('');
      setError(null);
      try {
        window.DragonBridge.startVoiceRecognition();
      } catch (e) {
        setVoiceState('error');
        setError('Bridge Connection Failed');
      }
    } else {
      console.warn("DragonBridge Native Interface not found.");
      setVoiceState('error');
      setError('Voice not supported on this device');
    }
  }, []);

  const stopListening = useCallback(() => {
    // Native recognizer handles its own lifecycle, but we reset UI state if needed
    setVoiceState('idle');
  }, []);

  const reset = useCallback(() => {
    setVoiceState('idle');
    setInterimTranscript('');
    setError(null);
  }, []);

  return { 
    isListening: voiceState === 'listening',
    voiceState,
    interimTranscript, 
    error,
    startListening, 
    stopListening,
    reset
  };
};
