
import { useState, useEffect, useCallback } from 'react';
import { Tab, BrowserViewMode, SearchEngine, TabGroup, AutoCloseDuration } from '../types';
import { normalizeUrl, getDisplayTitle } from '../utils/urlUtils';

const INITIAL_TAB: Tab = {
  id: '1',
  url: 'dragon://home',
  title: 'Dragon Browser',
  lastAccessed: Date.now(),
  isLoading: false,
  isPrivate: false,
  history: ['dragon://home'],
  currentIndex: 0,
  renderId: 0,
};

const generateId = () => Math.random().toString(36).substring(2, 15);

export const useTabs = (initialPrivateState: boolean, searchEngine: SearchEngine = 'dragon') => {
  const [tabs, setTabs] = useState<Tab[]>([INITIAL_TAB]);
  const [tabGroups, setTabGroups] = useState<TabGroup[]>([]);
  const [activeTabId, setActiveTabId] = useState<string>(INITIAL_TAB.id);
  const [viewMode, setViewMode] = useState<BrowserViewMode>(BrowserViewMode.BROWSER);
  const [closedTabs, setClosedTabs] = useState<Tab[]>([]);

  const activeTab = tabs.find(t => t.id === activeTabId) || tabs[0];

  // Hibernation Logic
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      setTabs(prev => prev.map(t => {
        if (t.id !== activeTabId && !t.isHibernating && (now - t.lastAccessed > 300000)) { 
          return { ...t, isHibernating: true };
        }
        return t;
      }));
    }, 60000); 
    return () => clearInterval(interval);
  }, [activeTabId]);

  // Wake on access
  useEffect(() => {
    if (activeTab.isHibernating) {
      setTabs(prev => prev.map(t => 
        t.id === activeTabId ? { ...t, isHibernating: false, lastAccessed: Date.now() } : t
      ));
    }
  }, [activeTabId, activeTab.isHibernating]);

  const createTab = useCallback((isPrivate?: boolean, groupId?: string) => {
    const newTab: Tab = {
      id: generateId(),
      url: 'dragon://home',
      title: 'Dragon Browser',
      lastAccessed: Date.now(),
      isLoading: false,
      isPrivate: isPrivate !== undefined ? isPrivate : initialPrivateState,
      history: ['dragon://home'],
      currentIndex: 0,
      groupId,
      renderId: 0
    };
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
    setViewMode(BrowserViewMode.BROWSER);
  }, [initialPrivateState]);

  const closeTab = useCallback((id: string) => {
    // Capture tab for restore before closing
    // Note: We use the current tabs state to find the tab
    setTabs(prev => {
      const tabToClose = prev.find(t => t.id === id);
      
      // Update closed tabs stack if it's not a private tab
      if (tabToClose && !tabToClose.isPrivate) {
        setClosedTabs(stack => [tabToClose, ...stack].slice(0, 10));
      }

      if (prev.length <= 1) {
        const resetTab = { ...INITIAL_TAB, id: generateId(), isPrivate: false, renderId: 0 };
        setActiveTabId(resetTab.id);
        return [resetTab];
      }
      const newTabs = prev.filter(t => t.id !== id);
      if (activeTabId === id) setActiveTabId(newTabs[newTabs.length - 1].id);
      return newTabs;
    });
  }, [activeTabId]);

  const restoreClosedTab = useCallback(() => {
    if (closedTabs.length === 0) return;

    const [tabToRestore, ...remaining] = closedTabs;
    setClosedTabs(remaining);

    // Create a new ID for the restored tab to ensure fresh state mount
    const newId = generateId();
    const restoredTab = { 
      ...tabToRestore, 
      id: newId, 
      lastAccessed: Date.now(),
      isHibernating: false,
      renderId: (tabToRestore.renderId || 0) + 1
    };

    setTabs(prev => [...prev, restoredTab]);
    setActiveTabId(newId);
    setViewMode(BrowserViewMode.BROWSER);
  }, [closedTabs]);

  // OMNIBOX NAVIGATION
  const navigateTab = useCallback((rawInput: string) => {
    const url = normalizeUrl(rawInput, searchEngine);
    setTabs(prev => prev.map(t => {
      if (t.id === activeTabId) {
        const newHistory = t.history.slice(0, t.currentIndex + 1);
        newHistory.push(url);
        return { 
          ...t, url, title: getDisplayTitle(url),
          isLoading: true, lastAccessed: Date.now(),
          history: newHistory, currentIndex: newHistory.length - 1,
          renderId: (t.renderId || 0) + 1
        };
      }
      return t;
    }));
    setViewMode(BrowserViewMode.BROWSER);
  }, [activeTabId, searchEngine]);

  // INTERNAL WEBVIEW SYNC (Links clicked inside pages)
  const handleInternalNavigate = useCallback((url: string) => {
    if (!url || url.startsWith('about:') || url.startsWith('dragon://')) return;

    setTabs(prev => prev.map(t => {
      if (t.id === activeTabId) {
        // Only update if the URL actually changed to prevent loops
        if (t.url === url) return t;

        const newHistory = t.history.slice(0, t.currentIndex + 1);
        newHistory.push(url);

        return {
          ...t,
          url: url, // RAW URL including parameters
          title: getDisplayTitle(url),
          lastAccessed: Date.now(),
          history: newHistory,
          currentIndex: newHistory.length - 1
          // NOTE: Do NOT increment renderId here. 
          // This keeps iframe src stable and prevents reload on internal navigation.
        };
      }
      return t;
    }));
  }, [activeTabId]);

  const reloadTab = useCallback(() => {
    setTabs(prev => prev.map(t => t.id === activeTabId ? { 
      ...t, 
      isLoading: true, 
      lastAccessed: Date.now(),
      renderId: (t.renderId || 0) + 1 
    } : t));
  }, [activeTabId]);

  const goBack = useCallback(() => {
    setTabs(prev => prev.map(t => {
      if (t.id === activeTabId && t.currentIndex > 0) {
        const newIndex = t.currentIndex - 1;
        const url = t.history[newIndex];
        return { 
          ...t, 
          currentIndex: newIndex, 
          url, 
          title: getDisplayTitle(url), 
          isLoading: true,
          renderId: (t.renderId || 0) + 1
        };
      }
      return t;
    }));
  }, [activeTabId]);

  const goForward = useCallback(() => {
    setTabs(prev => prev.map(t => {
      if (t.id === activeTabId && t.currentIndex < t.history.length - 1) {
        const newIndex = t.currentIndex + 1;
        const url = t.history[newIndex];
        return { 
          ...t, 
          currentIndex: newIndex, 
          url, 
          title: getDisplayTitle(url), 
          isLoading: true,
          renderId: (t.renderId || 0) + 1
        };
      }
      return t;
    }));
  }, [activeTabId]);

  const cleanupInactiveTabs = useCallback((duration: AutoCloseDuration) => {
    if (duration === 'never') return;

    const now = Date.now();
    let ms = 0;
    if (duration === '1day') ms = 24 * 60 * 60 * 1000;
    else if (duration === '3days') ms = 3 * 24 * 60 * 60 * 1000;
    else if (duration === '7days') ms = 7 * 24 * 60 * 60 * 1000;
    else return;

    setTabs(prev => {
      const activeId = activeTabId;
      const newTabs = prev.filter(t => {
        if (t.id === activeId) return true;
        if (t.pinned) return true;
        if ((now - t.lastAccessed) > ms) return false;
        return true;
      });

      if (newTabs.length === 0) {
         return [{ ...INITIAL_TAB, id: generateId(), lastAccessed: Date.now(), renderId: 0 }];
      }
      
      return newTabs;
    });
  }, [activeTabId]);

  const togglePinTab = useCallback((id: string) => {
    setTabs(prev => prev.map(t => t.id === id ? { ...t, pinned: !t.pinned } : t));
  }, []);

  const activateTab = useCallback((id: string) => {
    setActiveTabId(id);
    setTabs(prev => prev.map(t => t.id === id ? { ...t, lastAccessed: Date.now(), isHibernating: false } : t));
  }, []);

  return {
    tabs, tabGroups, activeTab, activeTabId, viewMode, setViewMode, setActiveTabId: activateTab,
    createTab, closeTab, navigateTab, handleInternalNavigate, reloadTab, goBack, goForward,
    setTabLoading: (isLoading: boolean) => setTabs(prev => prev.map(t => t.id === activeTabId ? { ...t, isLoading } : t)),
    setTabs, duplicateTab: (id: string) => {}, createTabGroup: (t: string) => "", deleteTabGroup: (id: string) => {}, updateTabGroup: (id: string, u: any) => {}, moveTabToGroup: (id: string, g?: string) => {},
    closeIncognitoTabs: () => {}, clearCurrentSession: () => {},
    cleanupInactiveTabs, togglePinTab,
    restoreClosedTab, canRestoreTab: closedTabs.length > 0
  };
};
