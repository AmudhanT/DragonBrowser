
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Search, Globe, Lock, Sparkles, Loader2, X, Clock, Star, TrendingUp } from 'lucide-react';
import { useDragon } from '../DragonContext';
import { useDragonAI } from '../hooks/useDragonAI';
import { Tab, SearchEngine } from '../types';

interface AddressBarProps {
  activeTab: Tab;
  urlInputValue: string;
  onUrlChange: (val: string) => void;
  onUrlSubmit: () => void;
  onReload: () => void;
  accentColor: string;
  onSiteSettingsClick?: () => void;
  onFocus?: () => void;
}

export const AddressBar: React.FC<AddressBarProps> = ({
  activeTab,
  urlInputValue,
  onUrlChange,
  onUrlSubmit,
  onReload,
  accentColor,
  onSiteSettingsClick,
  onFocus
}) => {
  const { suggestions: aiSuggestions, fetchSuggestions, setSuggestions } = useDragonAI();
  const { history, bookmarks, settings } = useDragon();
  const [showSuggestions, setShowSuggestions] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (urlInputValue && 
          document.activeElement === inputRef.current && 
          !urlInputValue.startsWith('http') && 
          !urlInputValue.includes('.')) {
        fetchSuggestions(urlInputValue);
      } else {
        setSuggestions([]);
      }
    }, 150); 
    return () => clearTimeout(timer);
  }, [urlInputValue, fetchSuggestions, setSuggestions]);

  // Enhanced Suggestion Merging for Address Bar (Compact View)
  const mergedSuggestions = useMemo(() => {
    if (!urlInputValue || urlInputValue.length < 1) return [];
    const query = urlInputValue.toLowerCase().trim();
    
    const scoredItems: { type: 'bookmark' | 'history' | 'web', label: string, value: string, score: number }[] = [];
    const seenValues = new Set<string>();

    const calculateScore = (text: string, baseScore: number) => {
      const lowerText = text.toLowerCase();
      if (lowerText === query) return baseScore + 20;
      if (lowerText.startsWith(query)) return baseScore + 10;
      if (lowerText.includes(query)) return baseScore;
      return 0;
    };

    // 1. Bookmarks (High Priority)
    bookmarks.forEach(b => {
      if (seenValues.has(b.url)) return;
      const score = Math.max(calculateScore(b.title, 50), calculateScore(b.url, 40));
      if (score > 0) {
        scoredItems.push({ type: 'bookmark', label: b.title || b.url, value: b.url, score });
        seenValues.add(b.url);
      }
    });

    // 2. History (Medium Priority + Recency)
    history.forEach(h => {
      if (seenValues.has(h.url)) return;
      const score = Math.max(calculateScore(h.title, 30), calculateScore(h.url, 20));
      if (score > 0) {
        // Boost slightly if extremely recent (last 24h)
        const recencyBonus = (Date.now() - h.timestamp) < 86400000 ? 5 : 0;
        scoredItems.push({ type: 'history', label: h.title || h.url, value: h.url, score: score + recencyBonus });
        seenValues.add(h.url);
      }
    });

    // 3. Web Suggestions (Lower Priority but Filler)
    aiSuggestions.forEach(s => {
      if (seenValues.has(s)) return;
      scoredItems.push({ type: 'web', label: s, value: s, score: 15 });
      seenValues.add(s);
    });

    // Sort descending by score, limit to 6 items for the smaller address bar dropdown
    return scoredItems.sort((a, b) => b.score - a.score).slice(0, 6);
  }, [urlInputValue, bookmarks, history, aiSuggestions]);

  const handleFocusInternal = () => {
    if (onFocus) {
      onFocus();
    } else {
      setShowSuggestions(true);
      inputRef.current?.select();
    }
  };

  const handleBlurInternal = () => {
    setTimeout(() => setShowSuggestions(false), 200);
  };

  const getSearchEngineLogo = (engine: SearchEngine) => {
    switch (engine) {
      case 'dragon':
        return <img src="https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg" className="w-4 h-4 rounded-full object-cover border border-white/10" alt="Dragon" />;
      case 'google':
        return (
          <svg viewBox="0 0 24 24" className="w-4 h-4">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" />
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.66l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
          </svg>
        );
      case 'bing':
        return (
          <svg viewBox="0 0 24 24" className="w-4 h-4">
            <path fill="#008373" d="M15.44 2.1L8.5 4.54V17.08L5.56 15.42V5.5L2 6.75V19.75L8.5 22.5L18.44 16.9V13.8L15.44 12.35V2.1H15.44Z" />
          </svg>
        );
      default: return <Search className="w-4 h-4 text-orange-500" />;
    }
  };

  const getSiteIcon = () => {
    if (activeTab.isPrivate) return <Lock className="w-4 h-4 text-purple-500 animate-pulse" />;
    
    const isInternal = activeTab.url.startsWith('dragon://');
    let domain = '';
    try {
      domain = isInternal ? 'dragon' : new URL(activeTab.url).hostname;
    } catch (e) {
      return <Globe className="w-4 h-4 text-slate-400" />;
    }
    
    if (isInternal) {
      return (
        <img 
          src="https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg"
          className="w-4 h-4 rounded-full object-cover"
          alt="D"
        />
      );
    }

    const isGoogle = domain.includes('google');
    const isBing = domain.includes('bing');
    
    if (settings.searchEngine === 'dragon' && isGoogle && activeTab.url.includes('/search')) {
       return getSearchEngineLogo('dragon');
    }
    if (settings.searchEngine === 'google' && isGoogle && activeTab.url.includes('/search')) {
       return getSearchEngineLogo('google');
    }
    if (settings.searchEngine === 'bing' && isBing) {
       return getSearchEngineLogo('bing');
    }

    return (
      <img 
        src={`https://www.google.com/s2/favicons?sz=64&domain=${domain}`}
        className="w-4 h-4 rounded-sm object-contain"
        onError={(e) => { (e.target as HTMLImageElement).src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjOTQ5OThmIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PGNpcmNsZSBjeD0iMTIiIGN5PSIxMiIgcj0iMTAiLz48bGluZSB4MT0iMiIgeTE9IjEyIiB4Mj0iMjIiIHkyPSIxMiIvPjxwYXRoIGQ9Ik0xMiAyYzIuODU1IDAgNSAxMCA1IDEwcy0yLjE0NSA0LTUgNHMtNS0xMC01LTEwczIuMTQ1LTQgNS00eiIvPjwvc3ZnPg=='; }}
        alt=""
      />
    );
  };

  const getSuggestionIcon = (type: string) => {
    switch(type) {
      case 'bookmark': return <Star className="w-3.5 h-3.5 text-orange-400" fill="currentColor" />;
      case 'history': return <Clock className="w-3.5 h-3.5 text-slate-400" />;
      case 'web': return <Search className="w-3.5 h-3.5 text-slate-400" />;
      default: return <Search className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  return (
    <div className="w-full relative group">
      <form 
        onSubmit={(e) => { 
          e.preventDefault(); 
          setShowSuggestions(false);
          inputRef.current?.blur();
          onUrlSubmit(); 
        }}
        className={`
          relative flex items-center bg-slate-100 dark:bg-dragon-navy/80 border rounded-2xl h-10 shadow-inner transition-all duration-300
          focus-within:bg-slate-200 dark:focus-within:bg-black/60 focus-within:border-slate-300 dark:focus-within:border-white/20 focus-within:shadow-lg
          ${activeTab.isPrivate ? 'border-purple-500/30' : 'border-slate-200 dark:border-white/5'}
        `}
      >
        <button 
          type="button" 
          onClick={onSiteSettingsClick}
          className="flex items-center shrink-0 pl-3 pr-2 h-full cursor-pointer hover:opacity-70 transition-opacity"
        >
          {getSiteIcon()}
        </button>

        <input
          id="dragon-url-input"
          ref={inputRef}
          className={`flex-1 bg-transparent border-none outline-none text-[13px] font-medium h-full px-1 focus:ring-0 min-w-0 text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-600`}
          value={urlInputValue}
          onChange={(e) => {
            onUrlChange(e.target.value);
            setShowSuggestions(true);
          }}
          onFocus={handleFocusInternal}
          onBlur={handleBlurInternal}
          placeholder="Search or enter address"
          autoCapitalize="off"
          autoComplete="off"
          spellCheck="false"
        />

        <div className="flex items-center gap-1 pr-2">
          {activeTab.isLoading && <Loader2 className="w-3.5 h-3.5 text-dragon-ember animate-spin mr-1" />}
          {urlInputValue && (
             <button 
               type="button" 
               onClick={() => onUrlChange('')}
               className="p-1.5 text-slate-400 hover:text-slate-900 dark:hover:text-white rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
             >
               <X size={12} />
             </button>
          )}
        </div>
      </form>

      {showSuggestions && mergedSuggestions.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-3 bg-white dark:bg-[#0d0f11]/95 backdrop-blur-3xl border border-slate-200 dark:border-white/10 rounded-2xl shadow-2xl overflow-hidden z-[100] animate-fade-in divide-y divide-slate-100 dark:divide-white/5 ring-1 ring-black/5 dark:ring-white/5">
          <div className="px-4 py-3 text-[9px] text-slate-500 uppercase tracking-widest font-black flex items-center gap-2 bg-slate-50 dark:bg-black/20">
            <Sparkles className="w-3 h-3 text-orange-500" /> Suggestions
          </div>
          {mergedSuggestions.map((s, idx) => (
            <button
              key={`suggestion-${idx}`}
              type="button"
              className="w-full text-left px-5 py-3 hover:bg-slate-50 dark:hover:bg-white/5 flex items-center gap-3 transition-all group"
              onMouseDown={(e) => {
                e.preventDefault();
                onUrlChange(s.value);
                onUrlSubmit();
                setShowSuggestions(false);
              }}
            >
              {getSuggestionIcon(s.type)}
              <div className="flex-1 min-w-0">
                 <span className="text-[12px] text-slate-700 dark:text-slate-300 font-bold truncate block group-hover:text-dragon-ember transition-colors">{s.label}</span>
                 {s.type !== 'web' && <span className="text-[9px] text-slate-400 truncate block mt-0.5 opacity-70">{s.value}</span>}
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
