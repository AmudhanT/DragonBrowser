
import React, { useRef, useEffect } from 'react';
import { Tab } from '../types';
import { Download, Video } from 'lucide-react';
import { useDragon } from '../DragonContext';

interface BrowserViewportProps {
  activeTab: Tab;
  onLoadStart: () => void;
  onLoadEnd: () => void;
  isDragonBreath: boolean;
  isDesktopMode?: boolean;
  javaScriptEnabled?: boolean;
  accentColor: string;
  onReload: () => void;
  refreshTrigger?: number;
  onInternalNavigate?: (url: string) => void;
}

export const BrowserViewport: React.FC<BrowserViewportProps> = ({ 
  activeTab, 
  onLoadEnd,
  isDesktopMode,
  javaScriptEnabled = true,
  refreshTrigger,
  onInternalNavigate
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { addDownload, getSitePermissions, settings } = useDragon();
  
  // Safety Timer: Prevents the browser from appearing "stuck" if a page loads partially
  useEffect(() => {
    if (activeTab.isLoading) {
      const timer = setTimeout(() => {
        onLoadEnd();
      }, 5000); // Force stop loading indicator after 5s
      return () => clearTimeout(timer);
    }
  }, [activeTab.isLoading, activeTab.url, refreshTrigger, onLoadEnd]);

  const handleLoad = () => {
    onLoadEnd();
  };

  const handleDownloadResource = () => {
    // Extract filename from URL
    let filename = 'download';
    try {
      const urlPath = new URL(activeTab.url).pathname;
      const extracted = urlPath.substring(urlPath.lastIndexOf('/') + 1);
      if (extracted && extracted.length < 50) filename = extracted;
    } catch (e) {}
    
    // User Confirmation for Video
    if (isVideo) {
        if (!window.confirm(`Start downloading video "${filename}"?`)) return;
    }
    
    addDownload(activeTab.url, filename);
  };

  if (activeTab.url === 'dragon://home') return null;

  // Detect Resource Type
  const cleanUrl = activeTab.url.split('?')[0].toLowerCase();
  const isPdf = cleanUrl.endsWith('.pdf');
  const isVideo = ['.mp4', '.webm', '.ogg', '.mkv', '.avi', '.mov', '.m3u8'].some(ext => cleanUrl.endsWith(ext));

  // Determine Display URL
  // PDFs use Google Viewer, Videos use native player (direct URL), others use direct URL
  const displayUrl = isPdf 
    ? `https://docs.google.com/gview?embedded=true&url=${encodeURIComponent(activeTab.url)}`
    : activeTab.url;

  // --- Permission Logic ---
  const sitePerms = getSitePermissions(activeTab.url);

  // Allow Scripts if global setting is ON AND site permission is ON
  const shouldAllowScripts = javaScriptEnabled && sitePerms.javascript;

  const sandboxRules = [
    "allow-forms",
    "allow-presentation",
    "allow-downloads",
    "allow-modals",
    "allow-orientation-lock",
    "allow-pointer-lock",
    "allow-top-navigation",
    "allow-top-navigation-by-user-activation"
  ];

  if (shouldAllowScripts) sandboxRules.push("allow-scripts");
  if (sitePerms.cookies) sandboxRules.push("allow-same-origin");
  if (sitePerms.popups) {
    sandboxRules.push("allow-popups");
    sandboxRules.push("allow-popups-to-escape-sandbox");
  }

  // Construct allow attribute for feature policy
  const allowFeatures = [];
  if (sitePerms.camera) allowFeatures.push("camera");
  if (sitePerms.microphone) allowFeatures.push("microphone");
  if (sitePerms.location) allowFeatures.push("geolocation");
  allowFeatures.push("accelerometer", "autoplay", "clipboard-write", "encrypted-media", "gyroscope", "picture-in-picture", "web-share", "fullscreen");
  
  if (settings.pipEnabled) {
    // picture-in-picture is already added above, but we ensure it's here
    if (!allowFeatures.includes('picture-in-picture')) allowFeatures.push('picture-in-picture');
  }

  return (
    <div 
      ref={containerRef}
      className="w-full h-full bg-white dark:bg-black relative overflow-hidden" 
      style={{ isolation: 'isolate' }}
    >
       <iframe
          src={displayUrl}
          className={`border-none bg-white block absolute top-0 left-0 transition-all duration-300 w-full h-full ${isDesktopMode ? 'origin-top-left' : ''}`}
          title={activeTab.title}
          sandbox={sandboxRules.join(' ')}
          allow={allowFeatures.join('; ')}
          loading="eager"
          onLoad={handleLoad}
          onError={handleLoad}
          // Include permissions in key to force re-render/reload when permissions change
          key={`${activeTab.url}-${refreshTrigger}-${isDesktopMode}-${javaScriptEnabled}-${sitePerms.lastModified}-${settings.pipEnabled}`}
          style={{
             colorScheme: 'normal',
             touchAction: 'auto',
             pointerEvents: 'auto',
             opacity: 1,
             // Simulating desktop mode iframing by setting a wider width and scaling it down
             width: isDesktopMode ? '1280px' : '100%',
             height: isDesktopMode ? 'calc(100% / 0.4)' : '100%',
             transform: isDesktopMode ? 'scale(calc(100vw / 1280))' : 'none'
          }}
        />
        
        {/* Resource Action Buttons */}
        {(isPdf || isVideo) && (
          <div className="absolute bottom-24 right-6 z-[60] animate-fade-in">
            <button
              onClick={handleDownloadResource}
              className={`
                flex items-center gap-2 px-5 py-3 rounded-full shadow-2xl transition-all active:scale-95 font-black uppercase text-[10px] tracking-widest border-2 border-white/20
                ${isVideo 
                  ? 'bg-red-600 hover:bg-red-700 text-white shadow-red-900/40' 
                  : 'bg-dragon-ember hover:bg-orange-600 text-white'
                }
              `}
            >
              {isVideo ? <Video size={16} /> : <Download size={16} />} 
              {isVideo ? 'Download Video' : 'Download PDF'}
            </button>
          </div>
        )}
    </div>
  );
};
