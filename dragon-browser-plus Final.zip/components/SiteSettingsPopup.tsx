
import React from 'react';
import { useDragon } from '../DragonContext';
import { 
  X, Shield, Lock, Globe, Video, Mic, MapPin, 
  Code, Cookie, Square, CheckSquare, RotateCcw 
} from 'lucide-react';
import { SitePermissions } from '../types';

interface SiteSettingsPopupProps {
  isOpen: boolean;
  onClose: () => void;
  url: string;
}

export const SiteSettingsPopup: React.FC<SiteSettingsPopupProps> = ({ isOpen, onClose, url }) => {
  const { getSitePermissions, updateSitePermissions, resetSitePermissions } = useDragon();
  
  if (!isOpen) return null;

  const domain = new URL(url).hostname;
  const permissions = getSitePermissions(url);

  const togglePermission = (key: keyof SitePermissions) => {
    updateSitePermissions(url, { [key]: !permissions[key] });
  };

  const items: { key: keyof SitePermissions; label: string; icon: React.ReactNode }[] = [
    { key: 'javascript', label: 'JavaScript', icon: <Code size={16} /> },
    { key: 'cookies', label: 'Cookies & Storage', icon: <Cookie size={16} /> },
    { key: 'location', label: 'Location Access', icon: <MapPin size={16} /> },
    { key: 'camera', label: 'Camera', icon: <Video size={16} /> },
    { key: 'microphone', label: 'Microphone', icon: <Mic size={16} /> },
    { key: 'popups', label: 'Pop-ups & Redirects', icon: <Square size={16} /> },
  ];

  return (
    <div className="fixed inset-0 z-[150] flex items-end sm:items-center justify-center sm:p-4 animate-fade-in">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      
      <div className="relative w-full max-w-sm bg-[#0a0a0a] rounded-t-[2rem] sm:rounded-[2rem] border-t sm:border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
        {/* Header */}
        <div className="p-6 pb-4 border-b border-white/5 bg-white/5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-dragon-ember/10 flex items-center justify-center border border-dragon-ember/20">
              <Shield size={20} className="text-dragon-ember" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-black text-white uppercase tracking-tight">Site Settings</h3>
              <p className="text-[10px] font-mono text-slate-400 truncate max-w-[200px]">{domain}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white bg-white/5 rounded-full transition-colors">
            <X size={18} />
          </button>
        </div>

        {/* Permissions List */}
        <div className="p-4 space-y-2 overflow-y-auto no-scrollbar">
          {items.map((item) => (
            <button
              key={item.key}
              onClick={() => togglePermission(item.key)}
              className="w-full flex items-center justify-between p-4 rounded-xl hover:bg-white/5 transition-all border border-transparent hover:border-white/5 group"
            >
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${permissions[item.key] ? 'text-dragon-cyan bg-dragon-cyan/10' : 'text-slate-500 bg-white/5'}`}>
                  {item.icon}
                </div>
                <span className={`text-xs font-bold uppercase tracking-wider ${permissions[item.key] ? 'text-slate-200' : 'text-slate-500'}`}>
                  {item.label}
                </span>
              </div>
              
              <div className={`w-10 h-6 rounded-full relative transition-all duration-300 ${permissions[item.key] ? 'bg-dragon-cyan' : 'bg-slate-800'}`}>
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-md transition-all duration-300 ${permissions[item.key] ? 'translate-x-5' : 'translate-x-1'}`} />
              </div>
            </button>
          ))}
        </div>

        {/* Footer */}
        <div className="p-4 bg-black/40 border-t border-white/5">
          <button 
            onClick={() => { resetSitePermissions(url); onClose(); }}
            className="w-full py-3 flex items-center justify-center gap-2 text-xs font-black text-red-500 hover:bg-red-500/10 rounded-xl transition-all uppercase tracking-widest"
          >
            <RotateCcw size={14} /> Reset Permissions
          </button>
        </div>
      </div>
    </div>
  );
};
