
import React, { useState, useRef } from 'react';
import { 
  Shield, Moon, Sun, 
  Bookmark, Download, History, Palette, 
  X, ChevronRight, Settings, ChevronLeft, Image as ImageIcon, Layout,
  Camera, Mic, Monitor, Globe, Star, Plus, Check, Upload, ShieldCheck, FileText,
  Smartphone, Pencil, SlidersHorizontal, ToggleLeft, ToggleRight, LayoutGrid
} from 'lucide-react';
import { useDragon } from '../DragonContext';
import { BrowserViewMode, ThemeMode, ToolbarConfig } from '../types';

export const MainMenu: React.FC = () => {
  const { settings, updateSettings, setViewMode, setNotesEntrySource, bookmarks, history, downloads, notes, setSettingsSection, setSettingsSource, t } = useDragon();

  const handleToggleNightMode = () => {
    let nextMode: ThemeMode = 'dark';
    if (settings.themeMode === 'dark') nextMode = 'system';
    else if (settings.themeMode === 'system') nextMode = 'light';
    else if (settings.themeMode === 'light') nextMode = 'dark';
    updateSettings({ themeMode: nextMode });
  };

  const handleToggleAdBlock = () => {
    updateSettings({ adBlockEnabled: !settings.adBlockEnabled });
  };

  const navigateTo = (mode: BrowserViewMode) => {
    if (mode === BrowserViewMode.NOTES_LIBRARY) {
      setNotesEntrySource('menu');
    }
    setViewMode(mode);
  };

  const openSettings = () => {
    setSettingsSection('MAIN');
    setSettingsSource('internal');
    setViewMode(BrowserViewMode.SETTINGS);
  };

  const openAppearance = () => {
    setSettingsSection('APPEARANCE');
    setSettingsSource('menu');
    setViewMode(BrowserViewMode.SETTINGS);
  };

  const getThemeLabel = () => {
    if (settings.themeMode === 'dark') return t('dark');
    if (settings.themeMode === 'light') return t('light');
    return t('auto');
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-[#0a0a0a] text-slate-900 dark:text-slate-100 animate-fade-in overflow-y-auto no-scrollbar transition-colors duration-300">
      {/* Top Bar */}
      <div className="px-6 pt-safe-top flex justify-between items-center h-16 shrink-0">
        <button 
          onClick={() => navigateTo(BrowserViewMode.BROWSER)}
          className="p-3 bg-white dark:bg-[#1a1a1a] border border-slate-200 dark:border-white/5 rounded-2xl text-slate-400 hover:text-dragon-ember transition-all active:scale-90 shadow-sm"
        >
          <X size={22} />
        </button>

        <button 
          onClick={openSettings}
          className="p-3 bg-white dark:bg-[#1a1a1a] border border-slate-200 dark:border-white/5 rounded-2xl text-slate-400 hover:text-dragon-ember transition-all active:scale-90 shadow-sm"
        >
          <Settings size={22} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar p-6 space-y-8">
        
        {/* Quick Toggles */}
        <div className="grid grid-cols-2 gap-4">
          {/* Theme Mode */}
          <button 
            onClick={handleToggleNightMode}
            className="p-5 rounded-[2rem] border bg-white dark:bg-[#151515] border-slate-200 dark:border-white/5 flex flex-col gap-4 relative overflow-hidden transition-all active:scale-[0.98] hover:border-slate-300 dark:hover:border-white/10 shadow-sm text-left"
          >
            <div className="flex justify-between items-start w-full">
              <div className="p-3 rounded-2xl bg-slate-100 dark:bg-white/5 text-slate-500 dark:text-slate-400">
                {settings.themeMode === 'light' ? <Sun size={20} /> : settings.themeMode === 'dark' ? <Moon size={20} /> : <Smartphone size={20} />}
              </div>
            </div>
            <div>
              <span className="text-[13px] font-black uppercase tracking-tight block text-slate-800 dark:text-slate-200">{t('system_mode')}</span>
              <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">{getThemeLabel()}</span>
            </div>
          </button>

          {/* Adblock */}
          <button 
            onClick={handleToggleAdBlock}
            className={`p-5 rounded-[2rem] border flex flex-col gap-4 relative overflow-hidden transition-all active:scale-[0.98] text-left ${settings.adBlockEnabled ? 'bg-dragon-navy border-dragon-ember/30 shadow-lg shadow-dragon-ember/10' : 'bg-white dark:bg-[#151515] border-slate-200 dark:border-white/5'}`}
          >
            <div className="flex justify-between items-start w-full relative z-10">
              <div className={`p-3 rounded-2xl ${settings.adBlockEnabled ? 'bg-dragon-ember/20 text-dragon-ember' : 'bg-slate-100 dark:bg-white/5 text-slate-400'}`}>
                <Shield size={20} />
              </div>
              <div className={`w-2 h-2 rounded-full ${settings.adBlockEnabled ? 'bg-dragon-ember animate-pulse' : 'bg-slate-300 dark:bg-slate-700'}`} />
            </div>
            <div className="relative z-10">
              <span className={`text-[13px] font-black uppercase tracking-tight block ${settings.adBlockEnabled ? 'text-white' : 'text-slate-800 dark:text-slate-200'}`}>Adblock</span>
              <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">{settings.adBlockEnabled ? 'On' : 'Off'}</span>
            </div>
            {settings.adBlockEnabled && <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-dragon-ember/5 rounded-full blur-2xl" />}
          </button>
        </div>

        {/* Feature Grid */}
        <div className="space-y-4">
          <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-2">{t('essentials')}</h3>
          <div className="grid grid-cols-2 gap-3">
            {[
              { id: 'bookmarks', label: t('bookmarks'), icon: <Bookmark size={20} />, color: 'text-orange-500', bg: 'bg-orange-500/10', count: bookmarks.length, action: () => navigateTo(BrowserViewMode.BOOKMARKS) },
              { id: 'downloads', label: t('downloads'), icon: <Download size={20} />, color: 'text-green-500', bg: 'bg-green-500/10', count: downloads.length, action: () => navigateTo(BrowserViewMode.DOWNLOADS) },
              { id: 'history', label: t('history'), icon: <History size={20} />, color: 'text-blue-500', bg: 'bg-blue-500/10', count: history.length, action: () => navigateTo(BrowserViewMode.HISTORY) },
              { id: 'notes', label: t('notes'), icon: <FileText size={20} />, color: 'text-pink-500', bg: 'bg-pink-500/10', count: notes.length, action: () => navigateTo(BrowserViewMode.NOTES_LIBRARY) },
            ].map((item) => (
              <button
                key={item.id}
                onClick={item.action}
                className="flex flex-col gap-3 p-5 bg-white dark:bg-[#151515] border border-slate-200 dark:border-white/5 rounded-[2rem] hover:bg-slate-50 dark:hover:bg-[#1a1a1a] transition-all text-left shadow-sm active:scale-95"
              >
                <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${item.bg} ${item.color}`}>
                  {item.icon}
                </div>
                <div>
                  <span className="text-[12px] font-black uppercase text-slate-800 dark:text-slate-200 block tracking-tight">{item.label}</span>
                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{item.count} {t('items')}</span>
                </div>
              </button>
            ))}
            
            {/* Added Appearance Button */}
            <button
              onClick={openAppearance}
              className="flex flex-col gap-3 p-5 bg-white dark:bg-[#151515] border border-slate-200 dark:border-white/5 rounded-[2rem] hover:bg-slate-50 dark:hover:bg-[#1a1a1a] transition-all text-left shadow-sm active:scale-95 col-span-2"
            >
              <div className="w-10 h-10 rounded-2xl flex items-center justify-center bg-purple-500/10 text-purple-500">
                <Palette size={20} />
              </div>
              <div>
                <span className="text-[12px] font-black uppercase text-slate-800 dark:text-slate-200 block tracking-tight">{t('appearance')}</span>
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{t('customize_look')}</span>
              </div>
            </button>
          </div>
        </div>
        
        <div className="h-6" />
      </div>
    </div>
  );
};
